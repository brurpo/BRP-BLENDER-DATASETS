"""Local search index for datasets that only ship metadata as big chunk files.

Objaverse (160 shards) and ABO (16 listing files) have no search API. The first time a chunk
is needed it is downloaded and parsed, and its entries go into a small SQLite file in the
cache. After that, searching that chunk is a database query instead of a re-parse, and
missing chunks are fetched several at a time. Nothing is indexed until a search or scroll
reaches it.
"""

import json
import os
import sqlite3
import threading
from concurrent.futures import ThreadPoolExecutor

VERSION = 1      # bump when the entry format changes; old index files are ignored
PARALLEL = 8     # chunks downloaded at once

_locks = {}
_locks_guard = threading.Lock()


def _chunk_lock(key, chunk):
    with _locks_guard:
        return _locks.setdefault((key, chunk), threading.Lock())


def _path(cache):
    d = os.path.join(cache, "index")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, f"search-v{VERSION}.db")


def _connect(cache):
    con = sqlite3.connect(_path(cache), timeout=30)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript("""
        CREATE TABLE IF NOT EXISTS items (
            src TEXT, chunk INTEGER, ord INTEGER, text TEXT, tex INTEGER, com INTEGER, entry TEXT,
            PRIMARY KEY (src, chunk, ord)) WITHOUT ROWID;
        CREATE TABLE IF NOT EXISTS chunks (src TEXT, chunk INTEGER, PRIMARY KEY (src, chunk));
    """)
    return con


def search_text(e):
    return " ".join(str(f) for f in (e["id"], e["name"], e["cat"], e["x"].get("kw")) if f).lower()


def indexed(cache, key):
    con = _connect(cache)
    try:
        return {c for (c,) in con.execute("SELECT chunk FROM chunks WHERE src=?", (key,))}
    finally:
        con.close()


def fill(cache, key, chunks, load):
    """Download and index the given chunks in parallel. load(i) returns chunk i's entries."""

    def one(c):
        with _chunk_lock(key, c):
            con = _connect(cache)
            try:
                if con.execute("SELECT 1 FROM chunks WHERE src=? AND chunk=?", (key, c)).fetchone():
                    return
                rows = load(c)
                tex = lambda e: None if e["tex"] is None else int(bool(e["tex"]))
                with con:
                    con.execute("DELETE FROM items WHERE src=? AND chunk=?", (key, c))
                    con.executemany(
                        "INSERT INTO items VALUES (?,?,?,?,?,?,?)",
                        ((key, c, i, search_text(e), tex(e), int(bool(e["com"])),
                          json.dumps(e, separators=(",", ":"))) for i, e in enumerate(rows)))
                    con.execute("INSERT OR IGNORE INTO chunks VALUES (?,?)", (key, c))
            finally:
                con.close()

    with ThreadPoolExecutor(min(PARALLEL, len(chunks)) or 1) as ex:
        for f in [ex.submit(one, c) for c in chunks]:
            f.result()  # re-raise download errors


def query(cache, key, chunk, ws, flt, offset, limit):
    """Entries in one chunk that contain every word and pass the filters, in file order."""
    sql = "SELECT entry FROM items WHERE src=? AND chunk=?"
    args = [key, chunk]
    for w in ws:
        sql += " AND text LIKE ? ESCAPE '\\'"
        args.append("%" + w.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
    if flt.get("textured"):
        sql += " AND (tex IS NULL OR tex=1)"
    if flt.get("commercial"):
        sql += " AND com=1"
    sql += " ORDER BY ord LIMIT ? OFFSET ?"
    args += [limit, offset]
    con = _connect(cache)
    try:
        return [json.loads(r) for (r,) in con.execute(sql, args)]
    finally:
        con.close()
