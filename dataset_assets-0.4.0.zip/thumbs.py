"""Thumbnails, fetched only for tiles that are on screen.

Worker threads download to a disk cache and decode with Blender's imbuf module (nothing is
added to bpy.data, so browsing never touches the .blend). The draw callback turns decoded
pixels into GPU textures a few at a time.
"""

import collections
import hashlib
import os
import threading
import time

import imbuf
import numpy as np

from . import net
from .sources import BY_KEY

SIZE = 256          # longest side of a decoded thumbnail
MAX_TEXTURES = 600  # GPU textures kept before the oldest are dropped
FAILED = "failed"
BACKDROP = 0.13  # grey behind the thumbnails in the browser


class Thumbs:
    def __init__(self):
        self.cache_dir = ""
        self.lock = threading.Lock()
        self.wanted = {}                      # key -> (source key, entry, time last asked for)
        self.stack = []                       # keys to fetch, newest request on top
        self.busy = set()
        self.ready = collections.deque()      # (key, w, h, bytes) waiting for upload
        self.textures = collections.OrderedDict()  # key -> GPUTexture or FAILED
        self.redraw = False
        self.epoch = 0

    # ---------------------------------------------------------------- main thread

    def get(self, src_key, e):
        """GPU texture for an entry, FAILED, or None while it loads (queues it)."""
        k = f"{src_key}/{e['id']}"
        t = self.textures.get(k)
        if t is not None:
            self.textures.move_to_end(k)
            return t
        with self.lock:
            fresh = k not in self.wanted
            self.wanted[k] = (src_key, e, time.time())
            if fresh and k not in self.busy:
                self.stack.append(k)
        return None

    def upload(self, limit=12):
        import gpu
        n = 0
        while self.ready and n < limit:
            k, w, h, data = self.ready.popleft()
            if data is None:
                self.textures[k] = FAILED
                continue
            try:
                buf = gpu.types.Buffer("FLOAT", w * h * 4, data)
                self.textures[k] = gpu.types.GPUTexture((w, h), format="RGBA8", data=buf)
            except Exception as ex:
                print("dataset_assets: thumbnail upload failed:", ex)
                self.textures[k] = FAILED
            n += 1
        while len(self.textures) > MAX_TEXTURES:
            self.textures.popitem(last=False)
        if self.ready:
            self.redraw = True

    def retry_failed(self):
        for k in [k for k, v in self.textures.items() if v is FAILED]:
            del self.textures[k]
            with self.lock:
                self.wanted.pop(k, None)

    def drop_textures(self):
        self.textures.clear()
        self.ready.clear()
        with self.lock:
            self.wanted.clear()
            self.stack.clear()

    def forget_queue(self):
        """The view changed: stop fetching what is no longer on screen."""
        with self.lock:
            self.stack.clear()
            self.wanted.clear()

    # ---------------------------------------------------------------- workers

    def start(self, n):
        self.epoch += 1
        for _ in range(n):
            threading.Thread(target=self._work, args=(self.epoch,), daemon=True).start()

    def shutdown(self):
        self.epoch += 1  # running workers see the change and exit

    def _next(self):
        with self.lock:
            now = time.time()
            while self.stack:
                k = self.stack.pop()
                w = self.wanted.get(k)
                if w is None:
                    continue
                if now - w[2] > 2.0:  # scrolled away; it is asked for again if it comes back
                    del self.wanted[k]
                    continue
                self.busy.add(k)
                return k, w
        return None, None

    def _work(self, epoch):
        while self.epoch == epoch:
            k, w = self._next()
            if k is None:
                time.sleep(0.05)
                continue
            src_key, e, _ = w
            result = (k, 0, 0, None)
            try:
                path = self._fetch(src_key, e)
                if path:
                    result = (k, *self._decode(path))
            except Exception:
                pass
            finally:
                with self.lock:
                    self.busy.discard(k)
                    self.wanted.pop(k, None)
            self.ready.append(result)
            self.redraw = True

    def _file(self, src_key, id):
        h = hashlib.sha1(id.encode("utf-8")).hexdigest()[:24]
        return os.path.join(self.cache_dir, "thumbs", src_key, h[:2], h + ".img")

    def _fetch(self, src_key, e):
        path = self._file(src_key, e["id"])
        if os.path.exists(path):
            return path
        if os.path.exists(path + ".none"):
            return None
        url, size = BY_KEY[src_key].resolve_thumb(e)
        if size:
            e["size"] = size
        if url:
            e["thumb"] = url
            try:
                data = net.get_bytes(url, retries=2)
            except RuntimeError as ex:
                if "HTTP 4" not in str(ex):
                    return None  # network trouble: try again next time
                data = None
            if data and len(data) > 200:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path + ".part", "wb") as f:
                    f.write(data)
                os.replace(path + ".part", path)
                return path
        # Remember assets that have no thumbnail so they aren't asked for again.
        os.makedirs(os.path.dirname(path), exist_ok=True)
        open(path + ".none", "wb").close()
        return None

    @staticmethod
    def _decode(path):
        ib = imbuf.load(path)
        try:
            w, h = ib.size
            if max(w, h) > SIZE:
                s = SIZE / max(w, h)
                ib.resize((max(1, round(w * s)), max(1, round(h * s))), method="BILINEAR")
                w, h = ib.size
            if ib.buffer_type != "BYTE":
                ib.convert_buffer_type("BYTE")
            with ib.with_buffer() as buf:
                data = bytes(buf)
        finally:
            ib.free()
        if len(data) != w * h * 4:
            raise RuntimeError("unexpected pixel layout")
        # GPUTexture only takes float buffers; convert here, off the main thread. Transparent
        # thumbnails are flattened onto the tile background so they never show as black.
        px = np.frombuffer(data, dtype=np.uint8).astype(np.float32).reshape(-1, 4) * (1.0 / 255.0)
        a = px[:, 3:4]
        px[:, :3] = px[:, :3] * a + BACKDROP * (1.0 - a)
        px[:, 3] = 1.0
        return w, h, px.ravel()


THUMBS = Thumbs()
