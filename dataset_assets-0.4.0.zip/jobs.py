"""Download-then-import jobs.

The download runs in a thread into a temporary folder. The add-on timer then imports it on
the main thread (in the main window's context), packs its images into the .blend and deletes
the temporary folder.
"""

import os
import shutil
import tempfile
import threading
import time

import bpy

from . import importer
from .sources import BY_KEY

TMP_ROOT = os.path.join(tempfile.gettempdir(), "dataset_assets_tmp")

CURRENT = None
MESSAGE = ("", "INFO")
MESSAGE_TIME = 0.0
redraw = False


def message(text, level="INFO"):
    global MESSAGE, MESSAGE_TIME, redraw
    MESSAGE, MESSAGE_TIME, redraw = (text, level), time.time(), True
    print(f"dataset_assets: {text}")


def prefs_dict():
    try:
        p = bpy.context.preferences.addons[__package__].preferences
        return {"polyhaven_resolution": p.polyhaven_resolution}
    except (KeyError, AttributeError):
        return {}


class Job:
    def __init__(self, key, e, normalize=False):
        self.key, self.entry, self.normalize = key, e, normalize
        self.done = self.total = 0
        self.status = "Starting"
        self.error = ""
        self.path = None
        self.finished = False
        self.cancel = False
        os.makedirs(TMP_ROOT, exist_ok=True)
        self.tmp = tempfile.mkdtemp(prefix=f"{key}_", dir=TMP_ROOT)

    def run(self, prefs):
        global redraw
        try:
            self.status = "Downloading"

            def progress(done, total):
                global redraw
                self.done, self.total = done, total
                redraw = True

            self.path = BY_KEY[self.key].download(self.entry, self.tmp, prefs, progress, lambda: self.cancel)
        except Exception as e:
            self.error = "Cancelled" if self.cancel else str(e)
        finally:
            self.finished = True
            redraw = True

    def cleanup(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


def attribution(key, e):
    return {
        "dataset": BY_KEY[key].label,
        "dataset_id": e["id"],
        "license": e["lic"],
        "source_url": e["page"],
        "attribution": f'"{e["name"]}" from {BY_KEY[key].label} ({e["page"]}), {e["lic"]}',
    }


def start(key, e, normalize):
    global CURRENT
    if CURRENT is not None:
        message("Another import is still running", "WARNING")
        return False
    if not bpy.app.online_access:
        message("Online access is off (Preferences > System > Network)", "ERROR")
        return False
    CURRENT = Job(key, e, normalize)
    threading.Thread(target=CURRENT.run, args=(prefs_dict(),), daemon=True).start()
    return True


def _main_context():
    """Window, area and region of a 3D View outside the browser window, for the importers."""
    from .window import UI
    wins = list(bpy.context.window_manager.windows)
    best = None
    for win in wins:
        for area in win.screen.areas:
            if area.as_pointer() == UI.area_ptr:
                continue
            if area.type == "VIEW_3D":
                region = next((r for r in area.regions if r.type == "WINDOW"), None)
                return {"window": win, "screen": win.screen, "area": area, "region": region}
            if best is None and area.type != "TEXT_EDITOR":
                best = {"window": win, "screen": win.screen}
    return best or {"window": wins[0], "screen": wins[0].screen}


def finish_if_done():
    """Called from the add-on timer on the main thread."""
    global CURRENT
    job = CURRENT
    if job is None or not job.finished:
        return
    CURRENT = None
    try:
        if job.error:
            message(job.error if job.error == "Cancelled" else f"Download failed: {job.error}",
                    "INFO" if job.error == "Cancelled" else "ERROR")
            return
        e = job.entry
        job.status = "Importing"
        try:
            with bpy.context.temp_override(**_main_context()):
                root, packed, failed = importer.import_asset(
                    bpy.context, job.path, e["name"][:60], BY_KEY[job.key].up_axis, job.normalize,
                    attribution(job.key, e))
                bpy.ops.ed.undo_push(message=f"Import {root.name}")
        except Exception as ex:
            message(f"Import failed: {ex}", "ERROR")
            return
        msg = f"Imported {root.name}: {packed} texture(s) stored in the .blend"
        if root.get("transparency", "opaque") != "opaque":
            msg += f"; transparency: {root['transparency_counts']}"
            if root.get("transparency_repairs"):
                msg += f" ({root['transparency_repairs']} material(s) rewired)"
        if failed:
            message(msg + f"; couldn't pack {', '.join(failed[:5])}", "WARNING")
        else:
            message(msg)
    finally:
        job.cleanup()


def import_entry(context, key, e, normalize=False, prefs=None):
    """Download and import synchronously (for scripts and tests)."""
    job = Job(key, e, normalize)
    try:
        job.run(prefs if prefs is not None else prefs_dict())
        if job.error:
            raise RuntimeError(job.error)
        return importer.import_asset(context, job.path, e["name"][:60], BY_KEY[key].up_axis, normalize,
                                     attribution(key, e))
    finally:
        job.cleanup()


def cancel_all():
    if CURRENT is not None:
        CURRENT.cancel = True
