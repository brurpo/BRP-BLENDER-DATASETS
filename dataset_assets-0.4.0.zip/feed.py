"""Live results for the browser: the current dataset + search + filters, loaded page by page.

Pages are fetched in background threads. Changing the search or filters starts a new
"generation" so late answers to an old query are dropped.

The "all" tab runs one page stream per dataset side by side; results show up as each dataset
answers, so a slow one never holds back the others. Every entry gets "src" (its dataset key).
"""

import threading

from .sources import ALL, BY_KEY

ALL_KEY = "all"


class _Stream:
    """Paging state for one dataset."""

    def __init__(self):
        self.cursor = None
        self.more = True
        self.loading = False
        self.error = ""
        self.total = None
        self.note = ""


class Feed:
    def __init__(self):
        self.cache_dir = ""
        self.key = ALL_KEY
        self.query = ""
        self.textured = True
        self.commercial = False
        self.gen = 0
        self.redraw = False
        self.lock = threading.Lock()
        self._reset()

    def _keys(self):
        return [s.key for s in ALL] if self.key == ALL_KEY else [self.key]

    def _reset(self):
        self.items = []
        self.ids = set()
        self.streams = {k: _Stream() for k in self._keys()}
        self._summary()

    def _summary(self):
        st = list(self.streams.values())
        self.loading = any(s.loading for s in st)
        self.more = any(s.more and not s.error for s in st)
        # Only a full failure stops the browser; in "all", a dataset that failed is noted instead.
        self.error = st[0].error if len(st) == 1 else ("; ".join(s.error for s in st) if all(s.error for s in st) else "")
        totals = [s.total for s in st]
        self.total = sum(totals) if all(t is not None for t in totals) and not self.more else (
            totals[0] if len(st) == 1 else None)
        if len(st) == 1:
            self.note = st[0].note
        else:
            failed = [BY_KEY[k].short for k, s in self.streams.items() if s.error]
            busy = [BY_KEY[k].short for k, s in self.streams.items() if s.loading]
            parts = []
            if busy:
                parts.append("Searching " + ", ".join(busy))
            if failed:
                parts.append("Couldn't reach " + ", ".join(failed))
            self.note = " · ".join(parts)

    def set(self, key=None, query=None, textured=None, commercial=None):
        new = (key if key is not None else self.key,
               query.strip() if query is not None else self.query,
               textured if textured is not None else self.textured,
               commercial if commercial is not None else self.commercial)
        if new == (self.key, self.query, self.textured, self.commercial):
            return False
        self.key, self.query, self.textured, self.commercial = new
        self.restart()
        return True

    def restart(self):
        with self.lock:
            self.gen += 1
            self._reset()
        self.redraw = True

    def request_more(self):
        flt = {"textured": self.textured, "commercial": self.commercial}
        with self.lock:
            for k, st in self.streams.items():
                if st.loading or not st.more or st.error:
                    continue
                if len(self.streams) > 1 and (k == "abo" and self.commercial or
                                              self.textured and not BY_KEY[k].has_textures):
                    st.more = False  # nothing this dataset could show with these filters
                    continue
                st.loading = True
                args = (self.gen, k, self.query, st.cursor, flt)
                threading.Thread(target=self._run, args=args, daemon=True).start()
            self._summary()

    def retry(self):
        with self.lock:
            for st in self.streams.values():
                st.error = ""
            self._summary()
        self.request_more()

    def _run(self, gen, key, query, cursor, flt):
        try:
            page = BY_KEY[key].page(query, cursor, flt, self.cache_dir)
            err = ""
        except Exception as e:  # network errors etc. are shown in the window
            page, err = None, str(e)[:300]
        with self.lock:
            if gen != self.gen:
                return
            st = self.streams[key]
            st.loading = False
            if page is None:
                st.error = err
            else:
                for e in page.items:
                    e["src"] = key
                    uid = (key, e["id"])
                    if uid not in self.ids:
                        self.ids.add(uid)
                        self.items.append(e)
                st.cursor = page.cursor
                st.more = page.cursor is not None
                st.total = page.total
                st.note = page.note
            self._summary()
        self.redraw = True


FEED = Feed()
