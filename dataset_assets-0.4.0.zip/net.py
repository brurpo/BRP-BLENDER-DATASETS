"""Small HTTP helpers on top of urllib (no extra dependencies)."""

import gzip
import json
import os
import time
import urllib.error
import urllib.request

UA = "DatasetAssets-Blender/0.2"


class Cancelled(Exception):
    pass


def _open(url, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    return urllib.request.urlopen(req, timeout=timeout)


def get_bytes(url, retries=3):
    for attempt in range(retries):
        try:
            with _open(url) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code < 500 and e.code != 429 or attempt == retries - 1:
                raise RuntimeError(f"GET {url}: HTTP {e.code}") from None
        except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
            if attempt == retries - 1:
                raise RuntimeError(f"GET {url}: {e}") from None
        time.sleep(1.5 * (attempt + 1))


def get_json(url):
    return json.loads(get_bytes(url))


def _next_link(link):
    for part in (link or "").split(","):
        if 'rel="next"' in part and "<" in part:
            nxt = part.split("<", 1)[1].split(">", 1)[0]
            return nxt
    return None


def get_json_headers(url):
    """GET JSON and return (data, response headers)."""
    try:
        with _open(url) as r:
            return json.loads(r.read()), dict(r.headers)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"GET {url}: HTTP {e.code}") from None
    except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
        raise RuntimeError(f"GET {url}: {e}") from None


def get_json_link(url):
    """GET one page of a JSON list and return (items, next page url or None)."""
    data, headers = get_json_headers(url)
    return data, _next_link(headers.get("Link"))


def get_json_paged(url):
    """GET a JSON list, following `Link: <...>; rel="next"` pagination (Hugging Face API)."""
    out = []
    while url:
        with _open(url) as r:
            link = r.headers.get("Link") or ""
            out.extend(json.loads(r.read()))
        url = _next_link(link)
    return out


def download(url, dest, progress=None, cancel=None):
    """Stream url to dest. progress(n_new_bytes, content_length) is called per chunk."""
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".part"
    try:
        with _open(url, timeout=120) as r, open(tmp, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            while True:
                if cancel and cancel():
                    raise Cancelled()
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                if progress:
                    progress(len(chunk), total)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"GET {url}: HTTP {e.code}") from None
    except BaseException:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    os.replace(tmp, dest)
    return os.path.getsize(dest)


def cached(url, path):
    """Download once into the cache and return the path."""
    if not os.path.exists(path):
        download(url, path)
    return path


def read_gz_text(path):
    with gzip.open(path, "rt", encoding="utf-8") as f:
        return f.read()


def url_path(p):
    return p.replace("%", "%25").replace(" ", "%20").replace("@", "%40").replace("#", "%23")
