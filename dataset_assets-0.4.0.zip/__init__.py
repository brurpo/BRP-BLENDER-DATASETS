"""Dataset Assets: a browser window for open 3D datasets that imports models straight into
the open .blend, with their textures packed into it.

Datasets: Poly Haven, Google Scanned Objects, NVIDIA SimReady, Objaverse 1.0,
Amazon Berkeley Objects. Results are fetched page by page as you browse; nothing is indexed
up front. Downloads go to a temporary folder that is deleted after import.

Open it from the top bar (Datasets), Add menu (Shift+A) or File > Import.
"""

import os
import shutil

import bpy
from bpy.props import EnumProperty, FloatProperty, IntProperty

from . import fab, jobs, window
from .feed import FEED
from .thumbs import THUMBS


def _cache_dir():
    try:
        return bpy.utils.extension_path_user(__package__, path="cache", create=True)
    except (ValueError, AttributeError):  # installed as a legacy add-on
        p = os.path.join(bpy.utils.user_resource("CONFIG"), "dataset_assets_cache")
        os.makedirs(p, exist_ok=True)
        return p


def _folder_size(path):
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


class DSA_OT_clear_cache(bpy.types.Operator):
    bl_idname = "dataset_assets.clear_cache"
    bl_label = "Clear Cache"
    bl_description = "Delete cached thumbnails and dataset pages (they download again when needed)"

    def execute(self, context):
        THUMBS.drop_textures()
        for name in os.listdir(FEED.cache_dir):
            if name in ("fab_edge_profile", "fab_downloads"):  # keeps the Fab sign-in and pending downloads
                continue
            shutil.rmtree(os.path.join(FEED.cache_dir, name), ignore_errors=True)
        FEED.restart()
        self.report({"INFO"}, "Cache cleared")
        return {"FINISHED"}


class DSA_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    polyhaven_resolution: EnumProperty(
        name="Poly Haven textures",
        items=[("1k", "1K", ""), ("2k", "2K", ""), ("4k", "4K", ""), ("8k", "8K", "")],
        default="2k",
    )
    thumb_workers: IntProperty(name="Thumbnail downloads", default=8, min=1, max=16,
                               description="Parallel thumbnail downloads (takes effect after restart)")
    tile_size: FloatProperty(name="Tile size", default=150.0, min=80.0, max=400.0, subtype="PIXEL",
                             description="Smallest tile width in the browser window")

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, "polyhaven_resolution")
        col.prop(self, "thumb_workers")
        col.prop(self, "tile_size")
        row = col.row()
        size = _folder_size(FEED.cache_dir) / 1e6 if FEED.cache_dir else 0
        row.label(text=f"Cache: {FEED.cache_dir} ({size:.0f} MB)", icon="FILE_FOLDER")
        row.operator(DSA_OT_clear_cache.bl_idname, icon="TRASH")


def _menu_topbar(self, context):
    self.layout.operator(window.DSA_OT_open_browser.bl_idname, text="Datasets", icon="ASSET_MANAGER")


def _menu_item(self, context):
    self.layout.separator()
    self.layout.operator(window.DSA_OT_open_browser.bl_idname, text="Dataset Asset Browser…", icon="ASSET_MANAGER")


def _tick():
    try:
        jobs.finish_if_done()
        fab.tick()
        if jobs.redraw:
            jobs.redraw = False
            FEED.redraw = True
        window.draw_tick()
    except Exception as ex:  # never let the timer die
        print("dataset_assets timer:", ex)
    return 0.2


MENUS = (
    (lambda: bpy.types.TOPBAR_MT_editor_menus, _menu_topbar),
    (lambda: bpy.types.VIEW3D_MT_add, _menu_item),
    (lambda: bpy.types.TOPBAR_MT_file_import, _menu_item),
)


def register():
    bpy.utils.register_class(DSA_OT_clear_cache)
    bpy.utils.register_class(DSA_Preferences)
    cache = _cache_dir()
    FEED.cache_dir = cache
    THUMBS.cache_dir = cache
    fab.State.cache_dir = cache
    window.register()
    for menu, fn in MENUS:
        menu().append(fn)
    shutil.rmtree(jobs.TMP_ROOT, ignore_errors=True)  # leftovers from a crash
    try:
        workers = bpy.context.preferences.addons[__package__].preferences.thumb_workers
    except (KeyError, AttributeError):  # preferences aren't attached yet on the very first enable
        workers = 8
    THUMBS.start(workers)
    bpy.app.timers.register(_tick, first_interval=0.5, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    jobs.cancel_all()
    fab.stop()
    THUMBS.shutdown()
    for menu, fn in MENUS:
        try:
            menu().remove(fn)
        except (AttributeError, ValueError):
            pass
    window.unregister()
    bpy.utils.unregister_class(DSA_Preferences)
    bpy.utils.unregister_class(DSA_OT_clear_cache)
