"""Repair and classify transparency on imported materials.

Self-contained (bpy + numpy only) so other tools can reuse it:

    from transparency import fix_transparency
    report = fix_transparency(objects)

What it repairs (Principled BSDF materials):
  * OBJ `map_d`: Blender links the opacity image's *Alpha* output, which is 1 everywhere for a
    grayscale map. Relinked from Color.
  * USD `opacity` driven by a texture without `opacityThreshold`: Blender turns it into
    Transmission (1 - opacity), i.e. glass instead of holes. Moved to Alpha (glass-named
    materials keep transmission).
  * Unlinked image nodes named like an opacity map (…_opacity, …_alpha, …_mask, …_cutout).
  * Base color textures with a real alpha channel when Alpha isn't linked (skipped for glTF,
    whose alphaMode OPAQUE says to ignore alpha; pass use_basecolor_alpha=False there).

Then each material is classified from what it actually does, and set up to preview in EEVEE
(Cycles uses the node tree directly):
  opaque         nothing transparent
  alpha_cutout   alpha is (nearly) 0/1: leaves, fences, decals. Render method Dithered
  alpha_blend    partial alpha: tinted plastic, smoke, soft decals. Render method Blended
  transmission   refractive glass/liquid. Dithered + raytraced refraction

Returns:
  {"materials": {name: {"class", "repairs", "alpha_source", "partial_fraction"}},
   "assets": {root object name: {"class", "counts"}},
   "counts": {"opaque": n, "alpha_cutout": n, "alpha_blend": n, "transmission": n},
   "repaired": n}

An asset's class is its "strongest" material class: transmission > alpha_blend >
alpha_cutout > opaque. The class is also stored as a "transparency" custom property on each
material and on each asset's root object.
"""

import os
import re

import bpy
import numpy as np

CLASSES = ("opaque", "alpha_cutout", "alpha_blend", "transmission")
OPACITY_NAME = re.compile(r"(opacity|alpha|transparen|cutout|_mask|mask_|_msk|_trans[._]|_op[._]|_o[._]|map_d)", re.I)
GLASS_NAME = re.compile(r"(glass|crystal|liquid|water|wine|beer|juice|lens|windscreen|windshield)", re.I)
CLIP_OPS = {"LESS_THAN", "GREATER_THAN", "ROUND", "COMPARE", "SNAP", "FLOOR", "CEIL"}
MAX_PIXELS = 2048 * 2048  # bigger images are scaled down on a copy before measuring
PARTIAL_CUTOUT = 0.35     # share of see-through pixels that may be partial and still count as cutout


# ---------------------------------------------------------------- node helpers

def _principled_nodes(mat):
    nt = mat.node_tree
    if nt is None:
        return []
    return [n for n in nt.nodes if n.type == "BSDF_PRINCIPLED"]


def _input(node, *names):
    for n in names:
        if n in node.inputs:
            return node.inputs[n]
    return None


def _from(sock):
    """(node, output socket) feeding an input, skipping reroutes."""
    if not sock.is_linked:
        return None, None
    link = sock.links[0]
    node, out = link.from_node, link.from_socket
    while node.type == "REROUTE" and node.inputs[0].is_linked:
        link = node.inputs[0].links[0]
        node, out = link.from_node, link.from_socket
    return node, out


def _trace(sock, depth=0):
    """Walk upstream from an input. Returns (image node, its output name, clipped?)."""
    node, out = _from(sock)
    if node is None or depth > 8:
        return None, None, False
    if node.type == "TEX_IMAGE":
        return node, out.name, False
    clipped = node.type == "MATH" and node.operation in CLIP_OPS
    for i in node.inputs:
        if i.is_linked:
            img, name, c = _trace(i, depth + 1)
            if img is not None:
                return img, name, clipped or c
    return None, None, clipped


def _image_has_alpha_channel(img):
    return img is not None and img.channels == 4 and img.depth in (32, 64, 128)


def _pixels(img):
    """Float RGBA pixels as an (N, 4) array, or None if the image can't be read."""
    if img is None or img.source not in ("FILE", "GENERATED") or not img.has_data and not img.packed_file and not img.filepath:
        return None
    tmp = None
    try:
        w, h = img.size
        if w * h == 0:
            return None
        src = img
        if w * h > MAX_PIXELS:
            tmp = img.copy()
            s = (MAX_PIXELS / (w * h)) ** 0.5
            tmp.scale(max(1, int(w * s)), max(1, int(h * s)))
            src = tmp
            w, h = src.size
        buf = np.empty(w * h * 4, dtype=np.float32)
        src.pixels.foreach_get(buf)
        return buf.reshape(-1, 4)
    except Exception:
        return None
    finally:
        if tmp is not None:
            bpy.data.images.remove(tmp)


def _coverage(img, output):
    """Values the alpha input would see: the image's alpha, or its luminance for Color."""
    px = _pixels(img)
    if px is None:
        return None
    if output == "Alpha":
        return px[:, 3]
    return px[:, :3] @ np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)


def _partial_fraction(values):
    """Share of the see-through pixels that are partly transparent (None = fully opaque)."""
    see = values < 0.98
    n = int(see.sum())
    if n == 0:
        return None
    partial = int((see & (values > 0.02)).sum())
    return partial / n


# ---------------------------------------------------------------- repairs

def _link(nt, out, sock):
    for l in list(sock.links):
        nt.links.remove(l)
    nt.links.new(out, sock)


def _repair(mat, bsdf, use_basecolor_alpha):
    nt = mat.node_tree
    alpha = _input(bsdf, "Alpha")
    trans = _input(bsdf, "Transmission Weight", "Transmission")
    base = _input(bsdf, "Base Color")
    repairs = []
    if alpha is None:
        return repairs
    base_img = _trace(base)[0] if base is not None else None

    # 1. Alpha taken from the Alpha output of an image with no alpha channel (OBJ map_d).
    node, out = _from(alpha)
    empty_alpha = False
    if node is not None and node.type == "TEX_IMAGE" and out.name == "Alpha" and node.image is not None:
        if not _image_has_alpha_channel(node.image):
            empty_alpha = True
        else:  # has an alpha channel, but it may be solid while the gray values hold the mask
            a = _coverage(node.image, "Alpha")
            empty_alpha = a is not None and _partial_fraction(a) is None
    if empty_alpha:
        if base_img is not None and node.image == base_img.image:
            for l in list(alpha.links):
                nt.links.remove(l)
            repairs.append("removed alpha link from an image without alpha")
        else:
            _link(nt, node.outputs["Color"], alpha)
            repairs.append("opacity map relinked from Color (was its empty Alpha channel)")

    # 2. Texture-driven USD opacity that became Transmission.
    if trans is not None and trans.is_linked and not alpha.is_linked and not GLASS_NAME.search(mat.name):
        img_node, img_out, _ = _trace(trans)
        node, _ = _from(trans)
        if img_node is not None and node is not None and node.type == "MATH" and node.operation == "SUBTRACT":
            # Transmission = 1 - opacity; feed opacity (the subtract's second input) to Alpha.
            src = node.inputs[1]
            src_node, src_out = _from(src)
            if src_out is not None:
                _link(nt, src_out, alpha)
                for l in list(trans.links):
                    nt.links.remove(l)
                trans.default_value = 0.0
                repairs.append("textured opacity moved from Transmission to Alpha")

    # 3. An opacity-looking texture that isn't connected to anything.
    if not alpha.is_linked:
        for n in nt.nodes:
            if n.type != "TEX_IMAGE" or n.image is None or any(o.is_linked for o in n.outputs):
                continue
            label = f"{n.image.name} {n.image.filepath} {n.label} {n.name}"
            if OPACITY_NAME.search(label):
                out = n.outputs["Alpha"] if _image_has_alpha_channel(n.image) and n.image.channels == 4 and \
                    re.search(r"rgba|_a\b", label, re.I) else n.outputs["Color"]
                _link(nt, out, alpha)
                repairs.append(f"unconnected opacity texture {n.image.name} linked to Alpha")
                break

    # 4. Base color texture whose alpha channel has real transparency.
    if not alpha.is_linked and use_basecolor_alpha and base_img is not None and _image_has_alpha_channel(base_img.image):
        cov = _coverage(base_img.image, "Alpha")
        if cov is not None and _partial_fraction(cov) is not None and float((cov < 0.5).mean()) > 0.002:
            _link(nt, base_img.outputs["Alpha"], alpha)
            repairs.append("base color alpha channel linked to Alpha")
    return repairs


# ---------------------------------------------------------------- classify and set up

def _classify(mat, bsdf):
    alpha = _input(bsdf, "Alpha")
    trans = _input(bsdf, "Transmission Weight", "Transmission")
    info = {"alpha_source": None, "partial_fraction": None}
    if trans is not None and (trans.is_linked or trans.default_value > 0.01):
        return "transmission", info
    if alpha is None:
        return "opaque", info
    if not alpha.is_linked:
        if alpha.default_value < 0.999:
            info["alpha_source"] = "constant"
            return "alpha_blend", info
        return "opaque", info
    img_node, out, clipped = _trace(alpha)
    if img_node is None:
        info["alpha_source"] = "nodes"
        return ("alpha_cutout" if clipped else "alpha_blend"), info
    info["alpha_source"] = f"{img_node.image.name if img_node.image else '?'}:{out}"
    if clipped:
        return "alpha_cutout", info
    cov = _coverage(img_node.image, out) if img_node.image else None
    if cov is None:
        return "alpha_blend", info  # can't read (e.g. UDIM): treat as soft to be safe
    frac = _partial_fraction(cov)
    if frac is None:
        return "opaque", info  # linked, but every pixel is opaque
    info["partial_fraction"] = round(frac, 3)
    return ("alpha_cutout" if frac <= PARTIAL_CUTOUT else "alpha_blend"), info


def _setattr(obj, name, value):
    if hasattr(obj, name):
        try:
            setattr(obj, name, value)
        except (TypeError, AttributeError):
            pass


def _setup(mat, cls):
    if cls == "opaque":
        return
    _setattr(mat, "use_transparent_shadow", True)
    if cls == "alpha_cutout":
        _setattr(mat, "surface_render_method", "DITHERED")
        _setattr(mat, "blend_method", "HASHED")
    elif cls == "alpha_blend":
        _setattr(mat, "surface_render_method", "BLENDED")
        _setattr(mat, "blend_method", "BLEND")
        _setattr(mat, "use_transparency_overlap", True)
        _setattr(mat, "use_backface_culling", False)
    elif cls == "transmission":
        _setattr(mat, "surface_render_method", "DITHERED")
        _setattr(mat, "use_raytrace_refraction", True)
        _setattr(mat, "use_screen_refraction", True)  # older EEVEE


def _root(o):
    while o.parent is not None:
        o = o.parent
    return o


def fix_transparency(objects, use_basecolor_alpha=True):
    """Repair alpha wiring on the objects' materials and classify them (see module doc)."""
    rank = {c: i for i, c in enumerate(CLASSES)}
    report = {"materials": {}, "assets": {}, "counts": dict.fromkeys(CLASSES, 0), "repaired": 0}
    mat_class = {}
    for o in objects:
        if o.type not in {"MESH", "CURVE", "SURFACE", "META", "FONT"}:
            continue
        for slot in o.material_slots:
            mat = slot.material
            if mat is None or mat.name in mat_class:
                continue
            bsdfs = _principled_nodes(mat)
            repairs, cls, info = [], "opaque", {"alpha_source": None, "partial_fraction": None}
            for b in bsdfs:
                repairs += _repair(mat, b, use_basecolor_alpha)
                c, i = _classify(mat, b)
                if rank[c] >= rank[cls]:
                    cls, info = c, i
            _setup(mat, cls)
            mat["transparency"] = cls
            mat_class[mat.name] = cls
            report["materials"][mat.name] = {"class": cls, "repairs": repairs, **info}
            report["counts"][cls] += 1
            report["repaired"] += bool(repairs)
    for o in objects:
        r = _root(o)
        a = report["assets"].setdefault(r.name, {"class": "opaque", "counts": dict.fromkeys(CLASSES, 0), "_m": set()})
        if o.type not in {"MESH", "CURVE", "SURFACE", "META", "FONT"}:
            continue
        for slot in o.material_slots:
            if slot.material is None or slot.material.name in a["_m"]:
                continue
            a["_m"].add(slot.material.name)
            c = mat_class[slot.material.name]
            a["counts"][c] += 1
            if rank[c] > rank[a["class"]]:
                a["class"] = c
    for name, a in report["assets"].items():
        del a["_m"]
        if name in bpy.data.objects:
            bpy.data.objects[name]["transparency"] = a["class"]
    return report


# ---------------------------------------------------------------- USD MDL (NVIDIA SimReady / Omniverse)
# Omniverse assets keep their real look in MDL shaders (OmniGlass, OmniPBR, OmniSurface).
# Blender imports only the UsdPreviewSurface fallback, which has no glass and no opacity map,
# so glass comes in opaque. This reads the MDL inputs with pxr and applies them.

def _usd_val(sh, name, default=None):
    i = sh.GetInput(name)
    if not i:
        return default
    v = i.Get()
    return default if v is None else v


def _usd_tex(sh, name):
    v = _usd_val(sh, name)
    p = getattr(v, "resolvedPath", "") if v is not None else ""
    return p or None


def _load_image(nt, path, non_color):
    img = bpy.data.images.load(path, check_existing=True)
    if non_color:
        img.colorspace_settings.is_data = True
    node = nt.nodes.new("ShaderNodeTexImage")
    node.image = img
    node.location = (-700, -450)
    # Reuse the UV mapping of an existing texture node, if any.
    for n in nt.nodes:
        if n is not node and n.type == "TEX_IMAGE" and n.inputs["Vector"].is_linked:
            nt.links.new(n.inputs["Vector"].links[0].from_socket, node.inputs["Vector"])
            break
    return node


def apply_usd_mdl(usd_path, objects):
    """Apply MDL glass/opacity settings from a USD file to the imported materials.
    Returns {material name: [changes]}. Silently does nothing without pxr or MDL shaders."""
    try:
        from pxr import Usd, UsdShade
    except ImportError:
        return {}
    mats = {}
    for o in objects:
        for slot in getattr(o, "material_slots", []):
            if slot.material is not None:
                mats.setdefault(slot.material.name.rsplit(".", 1)[0] if re.search(r"\.\d{3}$", slot.material.name)
                                else slot.material.name, []).append(slot.material)
    if not mats:
        return {}
    stage = Usd.Stage.Open(usd_path)
    changes = {}
    for prim in stage.Traverse(Usd.TraverseInstanceProxies()):
        if prim.GetTypeName() != "Shader" or prim.GetParent().GetName() not in mats:
            continue
        sh = UsdShade.Shader(prim)
        kind = sh.GetSourceAssetSubIdentifier("mdl") if sh.GetImplementationSource() == "sourceAsset" else None
        if not kind:
            continue
        for mat in mats[prim.GetParent().GetName()]:
            bsdfs = _principled_nodes(mat)
            if not bsdfs:
                continue
            bsdf, nt, done = bsdfs[0], mat.node_tree, []
            alpha = _input(bsdf, "Alpha")
            trans = _input(bsdf, "Transmission Weight", "Transmission")

            glass = kind.startswith("OmniGlass") or (
                kind.startswith("OmniSurface")
                and _usd_val(sh, "enable_specular_transmission", False)
                and _usd_val(sh, "specular_transmission_weight", 0.0) > 0.0)
            if glass and trans is not None:
                for l in list(trans.links):
                    nt.links.remove(l)
                trans.default_value = 1.0
                ior = _usd_val(sh, "glass_ior", _usd_val(sh, "specular_reflection_ior", 1.5))
                if _input(bsdf, "IOR") is not None:
                    bsdf.inputs["IOR"].default_value = float(ior)
                if _input(bsdf, "Metallic") is not None and not bsdf.inputs["Metallic"].is_linked:
                    bsdf.inputs["Metallic"].default_value = 0.0
                # Principled transmission is tinted by Base Color on every surface crossing, so the
                # fallback's albedo texture (often mid-grey on clear glass) turns it nearly black.
                # Use the glass colour, times only the hue of the colour texture.
                tint = [float(c) for c in (_usd_val(sh, "glass_color", _usd_val(sh, "specular_transmission_color"))
                                           or (1.0, 1.0, 1.0))][:3]
                tex = _usd_tex(sh, "glass_color_texture")
                if tex:
                    try:
                        img = bpy.data.images.load(tex, check_existing=True)
                        px = _pixels(img)
                        if px is not None:
                            mean = px[:, :3].mean(0)
                            hue = mean / max(float(mean.max()), 1e-6)
                            tint = [t * float(h) for t, h in zip(tint, hue)]
                    except RuntimeError:
                        pass
                base = _input(bsdf, "Base Color")
                if base is not None:
                    for l in list(base.links):
                        nt.links.remove(l)
                    base.default_value = (*tint, 1.0)
                done.append(f"{kind}: transmission 1, IOR {float(ior):.2f}")

            enable_opacity = _usd_val(sh, "enable_opacity", False)
            if alpha is not None and enable_opacity:
                tex = _usd_tex(sh, "opacity_texture") if _usd_val(sh, "enable_opacity_texture", True) else None
                if kind.startswith("OmniGlass"):
                    tex = _usd_tex(sh, "cutout_opacity_texture") if _usd_val(sh, "cutout_opacity_enable_texture", True) else None
                    const = _usd_val(sh, "cutout_opacity", 1.0)
                else:
                    const = _usd_val(sh, "opacity_constant", _usd_val(sh, "geometry_opacity", 1.0))
                threshold = float(_usd_val(sh, "opacity_threshold", _usd_val(sh, "geometry_opacity_threshold", 0.0)))
                for l in list(alpha.links):
                    nt.links.remove(l)
                if tex:
                    img = _load_image(nt, tex, non_color=True)
                    mode = int(_usd_val(sh, "opacity_mode", 1))  # 0 = alpha channel, else from color
                    out = img.outputs["Alpha"] if mode == 0 else img.outputs["Color"]
                    if threshold > 0.0:
                        m = nt.nodes.new("ShaderNodeMath")
                        m.operation = "GREATER_THAN"
                        m.inputs[1].default_value = threshold
                        m.location = (-400, -450)
                        nt.links.new(out, m.inputs[0])
                        out = m.outputs[0]
                    nt.links.new(out, alpha)
                    done.append(f"{kind}: opacity map {os.path.basename(tex)}" + (f" cut at {threshold:g}" if threshold else ""))
                else:
                    alpha.default_value = float(const)
                    done.append(f"{kind}: opacity {float(const):g}")
            if done:
                changes[mat.name] = done
    return changes
