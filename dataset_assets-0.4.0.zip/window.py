"""The browser window.

A separate Blender window whose single area is drawn entirely by this add-on with the gpu
and blf modules. A modal operator running in that window handles the mouse and keyboard.
Results stream in page by page as you scroll; thumbnails load only for visible tiles.
"""

import math
import os
import sys
import time

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader

from . import fab, jobs
from .feed import ALL_KEY, FEED
from .sources import ALL, BY_KEY
from .thumbs import FAILED, THUMBS

FONT = 0

BG = (0.105, 0.105, 0.105, 1.0)
BAR = (0.150, 0.150, 0.150, 1.0)
PANEL = (0.135, 0.135, 0.135, 1.0)
TILE = (0.175, 0.175, 0.175, 1.0)
TILE_HOVER = (0.235, 0.235, 0.235, 1.0)
FIELD = (0.075, 0.075, 0.075, 1.0)
BUTTON = (0.245, 0.245, 0.245, 1.0)
BUTTON_HOVER = (0.300, 0.300, 0.300, 1.0)
ACCENT = (0.278, 0.447, 0.702, 1.0)
ACCENT_HOVER = (0.330, 0.510, 0.780, 1.0)
TEXT = (0.92, 0.92, 0.92, 1.0)
DIM = (0.60, 0.60, 0.60, 1.0)
WARN = (0.95, 0.68, 0.30, 1.0)
ERROR = (0.95, 0.42, 0.40, 1.0)
GOOD = (0.50, 0.80, 0.50, 1.0)


class UI:
    area_ptr = 0
    mouse = (-1, -1)
    scroll = 0.0
    hits = []
    grid = None            # (x, y, w, h, row_h, content_h) from the last draw
    focus = False          # search field has keyboard focus
    text = ""
    text_changed = 0.0     # when the search text last changed (applied after a short pause)
    selected = None        # (source key, entry)
    normalize = False
    drag = None            # scrollbar drag: (mouse y at start, scroll at start)
    fab = False            # the Fab tab is showing
    fab_rect = None        # its web area in region pixels (x, y, w, h)


def is_open():
    if not UI.area_ptr:
        return False
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.as_pointer() == UI.area_ptr and area.type == "TEXT_EDITOR":
                return True
    return False


def browser_area():
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.as_pointer() == UI.area_ptr:
                return win, area
    return None, None


def tag_redraw():
    _, area = browser_area()
    if area:
        area.tag_redraw()


def raise_window(win):
    """Bring a Blender window to the front (Blender's API can't, so ask Windows directly)."""
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        pid = os.getpid()

        class PLACEMENT(ctypes.Structure):
            _fields_ = [("length", wintypes.UINT), ("flags", wintypes.UINT), ("showCmd", wintypes.UINT),
                        ("ptMin", wintypes.POINT), ("ptMax", wintypes.POINT), ("rcNormal", wintypes.RECT)]

        found = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def visit(hwnd, _):
            owner = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
            if owner.value == pid and user32.IsWindowVisible(hwnd):
                cls = ctypes.create_unicode_buffer(64)
                user32.GetClassNameW(hwnd, cls, 64)
                if cls.value == "GHOST_WindowClass":
                    pl = PLACEMENT()
                    pl.length = ctypes.sizeof(PLACEMENT)
                    user32.GetWindowPlacement(hwnd, ctypes.byref(pl))
                    r = pl.rcNormal
                    found.append((abs(r.right - r.left - win.width) + abs(r.bottom - r.top - win.height), hwnd))
            return True

        user32.EnumWindows(visit, 0)
        if not found:
            return False
        hwnd = min(found)[1]
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        if user32.GetForegroundWindow() == hwnd or user32.SetForegroundWindow(hwnd):
            return True
        # Windows refuses focus changes from a background process; a synthetic Alt tap lifts that.
        user32.keybd_event(0x12, 0, 0, 0)
        user32.keybd_event(0x12, 0, 2, 0)
        return bool(user32.SetForegroundWindow(hwnd))
    except Exception:
        return False


def closed():
    """The window went away: free GPU memory and forget the area."""
    UI.area_ptr = 0
    UI.focus = False
    UI.drag = None
    UI.fab = False
    fab.restart()  # closes Edge; the next visit to the tab starts it fresh
    THUMBS.drop_textures()


def human(n):
    if not n:
        return "size unknown"
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024


# ---------------------------------------------------------------- drawing helpers

_shaders = {}


def _shader(name):
    if name not in _shaders:
        _shaders[name] = gpu.shader.from_builtin(name)
    return _shaders[name]


def rect(x, y, w, h, color):
    if w <= 0 or h <= 0:
        return
    sh = _shader("UNIFORM_COLOR")
    batch = batch_for_shader(sh, "TRIS", {"pos": ((x, y), (x + w, y), (x, y + h), (x + w, y + h))},
                             indices=((0, 1, 2), (2, 1, 3)))
    sh.uniform_float("color", color)
    batch.draw(sh)


def outline(x, y, w, h, color, t=2):
    rect(x, y, w, t, color)
    rect(x, y + h - t, w, t, color)
    rect(x, y, t, h, color)
    rect(x + w - t, y, t, h, color)


def image(tex, x, y, w, h):
    """Draw a texture fitted (aspect kept) and centred in the box."""
    tw, th = tex.width, tex.height
    s = min(w / tw, h / th)
    dw, dh = tw * s, th * s
    x, y = x + (w - dw) / 2, y + (h - dh) / 2
    sh = _shader("IMAGE")
    batch = batch_for_shader(sh, "TRIS", {
        "pos": ((x, y), (x + dw, y), (x, y + dh), (x + dw, y + dh)),
        "texCoord": ((0, 0), (1, 0), (0, 1), (1, 1)),
    }, indices=((0, 1, 2), (2, 1, 3)))
    sh.uniform_sampler("image", tex)
    batch.draw(sh)


def font(size):
    blf.size(FONT, size)


def text(x, y, s, color=TEXT):
    blf.position(FONT, x, y, 0)
    blf.color(FONT, *color)
    blf.draw(FONT, s)


def width(s):
    return blf.dimensions(FONT, s)[0]


def fit(s, w):
    if width(s) <= w:
        return s
    lo, hi = 0, len(s)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if width(s[:mid] + "…") <= w:
            lo = mid
        else:
            hi = mid - 1
    return s[:lo].rstrip() + "…"


def wrap(s, w, max_lines):
    lines, cur = [], ""
    for word in s.split():
        trial = f"{cur} {word}" if cur else word
        if width(trial) <= w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = fit(lines[-1] + " …", w)
    return [fit(l, w) for l in lines]


def hovered(x, y, w, h):
    mx, my = UI.mouse
    return x <= mx < x + w and y <= my < y + h


def button(x, y, w, h, label, action, s, primary=False, enabled=True, on=False, size=None):
    hot = enabled and hovered(x, y, w, h)
    if primary or on:
        col = ACCENT_HOVER if hot else ACCENT
    else:
        col = BUTTON_HOVER if hot else BUTTON
    if not enabled:
        col = (col[0] * 0.6, col[1] * 0.6, col[2] * 0.6, 1.0)
    rect(x, y, w, h, col)
    font(size or 12 * s)
    tw = width(label)
    text(x + (w - tw) / 2, y + (h - 9 * s) / 2, label, TEXT if enabled else DIM)
    if enabled:
        UI.hits.append((x, y, w, h, action))


def checkbox(x, y, label, on, action, s):
    font(12 * s)
    box = 14 * s
    w = box + 6 * s + width(label)
    h = 24 * s
    hot = hovered(x, y, w, h)
    by = y + (h - box) / 2
    rect(x, by, box, box, ACCENT if on else (FIELD if not hot else BUTTON))
    if on:
        rect(x + box * 0.28, by + box * 0.28, box * 0.44, box * 0.44, TEXT)
    text(x + box + 6 * s, y + (h - 9 * s) / 2, label, TEXT if hot or on else DIM)
    UI.hits.append((x, y, w, h, action))
    return w


# ---------------------------------------------------------------- layout and draw

def metrics(region):
    s = bpy.context.preferences.system.ui_scale
    W, H = region.width, region.height
    top = 84 * s
    status = 26 * s
    detail = 300 * s if W > 640 * s else 0
    pad = 12 * s
    gap = 10 * s
    gx, gy = pad, status + 4 * s
    gw = W - detail - 2 * pad - 10 * s  # leaves room for the scrollbar
    gh = H - top - gy
    try:
        tile_min = bpy.context.preferences.addons[__package__].preferences.tile_size * s
    except (KeyError, AttributeError):
        tile_min = 150 * s
    cols = max(1, int((gw + gap) // (tile_min + gap)))
    tw = (gw - gap * (cols - 1)) / cols
    th = tw + 40 * s
    return s, W, H, top, status, detail, pad, gap, gx, gy, gw, gh, cols, tw, th


def draw():
    area = bpy.context.area
    if area is None or area.as_pointer() != UI.area_ptr:
        return
    region = bpy.context.region
    THUMBS.upload()
    UI.hits = []
    gpu.state.blend_set("ALPHA")
    try:
        _draw(region)
    finally:
        gpu.state.blend_set("NONE")


def _draw_tabs(s, W, H, pad, key):
    """Dataset tabs plus the Fab tab. Returns the row's y."""
    x = pad
    y1 = H - 8 * s - 28 * s
    tabs = [(ALL_KEY, "All")] + [(src.key, src.short) for src in ALL] + [("fab", "Fab Megascans")]
    font(12 * s)
    need = sum(width(t) + 30 * s for _, t in tabs)
    fs = max(0.6, min(1.0, (W - 2 * pad) / need))  # shrink the tab row to fit narrow windows
    for k, short in tabs:
        font(12 * s * fs)
        w = width(short) + 26 * s * fs
        on = UI.fab if k == "fab" else (k == key and not UI.fab)
        button(x, y1, w, 28 * s, short, ("fab",) if k == "fab" else ("source", k), s, on=on, size=12 * s * fs)
        x += w + 4 * s * fs
    if not bpy.app.online_access:
        font(12 * s)
        text(x + 12 * s, y1 + 9 * s, "Online access is off: Preferences > System > Network", ERROR)
    return y1


def _draw_fab(region):
    """Fab tab: the Edge window covers the web area; this draws the bars around it."""
    s = bpy.context.preferences.system.ui_scale
    W, H = region.width, region.height
    top, status, pad = 84 * s, 26 * s, 12 * s
    rect(0, 0, W, H, BG)
    UI.fab_rect = (0, status, W, H - top - status)
    # Shown only until Edge covers it (or if it can't).
    font(14 * s)
    if fab.State.error:
        msg = f"{fab.State.error}. Click Restart Fab to open it again."
    elif not fab.WIN:
        msg = "Fab opened in your web browser. Save downloads into the folder below to import them."
    else:
        msg = "Starting Microsoft Edge…"
    text((W - width(msg)) / 2, status + (H - top - status) / 2, msg, DIM)

    rect(0, H - top, W, top, BAR)
    rect(0, H - top, W, 1, (0.08, 0.08, 0.08, 1))
    y1 = _draw_tabs(s, W, H, pad, FEED.key)
    y2 = y1 - 8 * s - 28 * s
    bw = 150 * s
    button(W - pad - bw, y2, bw, 28 * s, "Downloads folder", ("fab_folder",), s)
    button(W - pad - 2 * bw - 8 * s, y2, bw, 28 * s, "Restart Fab", ("fab_restart",), s)
    font(12.5 * s)
    hint = ("Sign in with your Epic account and click Download on any Megascans asset. "
            "It is imported into this .blend automatically.")
    text(pad, y2 + 9 * s, fit(hint, W - 2 * bw - 3 * pad - 8 * s), TEXT)

    rect(0, 0, W, status, BAR)
    font(11.5 * s)
    right = fab.status()
    rw = width(right)
    text(W - pad - rw, 8 * s, right, DIM)
    msg, level = jobs.MESSAGE
    if msg and time.time() - jobs.MESSAGE_TIME < 20:
        text(pad, 8 * s, fit(msg, W - rw - 3 * pad), ERROR if level == "ERROR" else (WARN if level == "WARNING" else GOOD))
    else:
        text(pad, 8 * s, fit(f"Downloads go to {fab.download_dir()}", W - rw - 3 * pad), DIM)


def _draw(region):
    if UI.fab:
        _draw_fab(region)
        return
    s, W, H, top, status, detail, pad, gap, gx, gy, gw, gh, cols, tw, th = metrics(region)
    key = FEED.key
    rect(0, 0, W, H, BG)

    # ---- grid
    items = FEED.items
    row_h = th + gap
    rows = math.ceil(len(items) / cols)
    tail = 60 * s if (FEED.more or FEED.loading or FEED.error or not items) else 0
    content_h = rows * row_h + tail
    UI.scroll = max(0.0, min(UI.scroll, max(0.0, content_h - gh)))
    UI.grid = (gx, gy, gw, gh, row_h, content_h)
    gtop = gy + gh
    first = max(0, int(UI.scroll // row_h))
    last = int((UI.scroll + gh) // row_h) + 1
    sel = (UI.selected[0], UI.selected[1]["id"]) if UI.selected else None
    for i in range(first * cols, min(len(items), (last + 1) * cols)):
        e = items[i]
        r, c = divmod(i, cols)
        x = gx + c * (tw + gap)
        y = gtop - (r * row_h - UI.scroll) - th
        if y > gtop or y + th < gy:
            continue
        hot = hovered(x, y, tw, th) and gy <= UI.mouse[1] < gtop
        rect(x, y, tw, th, TILE_HOVER if hot else TILE)
        ip = 6 * s
        iw = tw - 2 * ip
        ix, iy = x + ip, y + th - ip - iw
        tex = THUMBS.get(e["src"], e)
        rect(ix, iy, iw, iw, (0.13, 0.13, 0.13, 1.0))
        if tex is FAILED:
            font(11 * s)
            text(ix + (iw - width("No preview")) / 2, iy + iw / 2, "No preview", DIM)
        elif tex is not None:
            image(tex, ix, iy, iw, iw)
        else:
            font(11 * s)
            text(ix + (iw - width("Loading…")) / 2, iy + iw / 2, "Loading…", DIM)
        font(12 * s)
        text(x + ip, y + 20 * s, fit(e["name"], tw - 2 * ip), TEXT)
        font(10.5 * s)
        sub = e["lic"] + (f" · {human(e['size'])}" if e["size"] else "")
        if key == ALL_KEY:
            sub = f"{BY_KEY[e['src']].short} · {sub}"
        text(x + ip, y + 7 * s, fit(sub, tw - 2 * ip), DIM if e["com"] else WARN)
        if (e["src"], e["id"]) == sel:
            outline(x, y, tw, th, ACCENT, max(2, int(2 * s)))
        if gy <= y + th / 2 <= gtop or hot:
            UI.hits.append((x, max(y, gy), tw, min(y + th, gtop) - max(y, gy), ("tile", i)))
    # Prefetch the next rows' thumbnails.
    for i in range((last + 1) * cols, min(len(items), (last + 3) * cols)):
        THUMBS.get(items[i]["src"], items[i])

    # tail: loading / end / errors
    ty = gtop - (rows * row_h - UI.scroll) - 30 * s
    font(13 * s)
    if FEED.error:
        msg = fit("Couldn't load: " + FEED.error, gw - 120 * s)
        text(gx, ty, msg, ERROR)
        button(gx + width(msg) + 12 * s, ty - 7 * s, 80 * s, 26 * s, "Retry", ("retry",), s)
    elif FEED.loading:
        text(gx, ty, "Loading" + "." * (int(time.time() * 3) % 4), DIM)
    elif not items:
        text(gx, ty, "No results" + (f" for “{FEED.query}”" if FEED.query else ""), DIM)
    # Load the next page when the end of what's loaded comes near.
    if FEED.more and not FEED.error and UI.scroll + gh > rows * row_h - 2 * row_h:
        FEED.request_more()

    # scrollbar
    if content_h > gh:
        sx = gx + gw + 3 * s
        bar_h = max(30 * s, gh * gh / content_h)
        frac = UI.scroll / (content_h - gh)
        by = gy + (gh - bar_h) * (1 - frac)
        rect(sx, gy, 6 * s, gh, (0.14, 0.14, 0.14, 1))
        rect(sx, by, 6 * s, bar_h, (0.38, 0.38, 0.38, 1))
        UI.hits.append((sx - 4 * s, gy, 14 * s, gh, ("scrollbar", by, bar_h)))

    # ---- top bar (drawn over the grid)
    rect(0, H - top, W, top, BAR)
    rect(0, H - top, W, 1, (0.08, 0.08, 0.08, 1))
    y1 = _draw_tabs(s, W, H, pad, key)
    y2 = y1 - 8 * s - 28 * s
    fw = max(160 * s, min(460 * s, W - detail - 420 * s))
    hot = hovered(pad, y2, fw, 28 * s)
    rect(pad, y2, fw, 28 * s, FIELD)
    if UI.focus:
        outline(pad, y2, fw, 28 * s, ACCENT, max(1, int(1.5 * s)))
    elif hot:
        outline(pad, y2, fw, 28 * s, BUTTON_HOVER, 1)
    font(13 * s)
    if UI.text:
        shown = UI.text
        while width(shown) > fw - 40 * s and len(shown) > 1:
            shown = shown[1:]
        text(pad + 10 * s, y2 + 9 * s, shown, TEXT)
        cx = pad + 10 * s + width(shown) + 1
        UI.hits.append((pad + fw - 26 * s, y2, 26 * s, 28 * s, ("clear",)))
        text(pad + fw - 19 * s, y2 + 9 * s, "×", DIM)
    else:
        cx = pad + 10 * s
        text(pad + 10 * s, y2 + 9 * s, f"Search {'all datasets' if key == ALL_KEY else BY_KEY[key].label}…", DIM)
    if UI.focus and int(time.time() * 2) % 2 == 0:
        rect(cx, y2 + 6 * s, max(1, s), 16 * s, TEXT)
    UI.hits.append((pad, y2, fw, 28 * s, ("search",)))
    x = pad + fw + 16 * s
    x += checkbox(x, y2 + 2 * s, "Textured", FEED.textured, ("toggle", "textured"), s) + 16 * s
    x += checkbox(x, y2 + 2 * s, "Commercial use OK", FEED.commercial, ("toggle", "commercial"), s) + 16 * s

    # ---- status bar
    rect(0, 0, W, status, BAR)
    font(11.5 * s)
    if FEED.total is not None:
        count = f"{len(items):,} of {FEED.total:,} shown"
    else:
        count = f"{len(items):,} shown" + (" · scroll for more" if FEED.more else "")
    right = count + (f" · {FEED.note}" if FEED.note else "")
    rw = width(right)
    text(W - pad - rw, 8 * s, right, DIM)
    msg, level = jobs.MESSAGE
    if msg and time.time() - jobs.MESSAGE_TIME < 20:
        text(pad, 8 * s, fit(msg, W - rw - 3 * pad), ERROR if level == "ERROR" else (WARN if level == "WARNING" else GOOD))
    else:
        note = "Searches every dataset at once" if key == ALL_KEY else BY_KEY[key].note
        text(pad, 8 * s, fit(note, W - rw - 3 * pad), DIM)

    # ---- details
    if detail:
        _draw_detail(s, W - detail, status, detail, H - top - status, pad)

    if FEED.loading or UI.focus:
        FEED.redraw = True  # keep the dots and the caret moving


def _draw_detail(s, x0, y0, w, h, pad):
    rect(x0, y0, w, h, PANEL)
    rect(x0, y0, 1, h, (0.08, 0.08, 0.08, 1))
    px, pw = x0 + pad, w - 2 * pad
    y = y0 + h - pad
    job = jobs.CURRENT
    if not UI.selected:
        font(13 * s)
        for line in wrap("Click an asset to see its details. Double-click a tile to import it.", pw, 4):
            y -= 20 * s
            text(px, y, line, DIM)
    else:
        key, e = UI.selected
        src = BY_KEY[key]
        y -= pw
        rect(px, y, pw, pw, (0.13, 0.13, 0.13, 1))
        tex = THUMBS.get(key, e)
        if tex is not None and tex is not FAILED:
            image(tex, px, y, pw, pw)
        y -= 8 * s
        font(15 * s)
        for line in wrap(e["name"], pw, 3):
            y -= 21 * s
            text(px, y, line, TEXT)
        y -= 6 * s
        font(12 * s)
        rows = [("Dataset", src.label, TEXT)]
        if e["cat"]:
            rows.append(("Category", e["cat"], TEXT))
        rows.append(("License", e["lic"] + ("" if e["com"] else "  (non-commercial)"), TEXT if e["com"] else WARN))
        rows.append(("Size", human(e["size"]), TEXT))
        rows.append(("Textures", {True: "yes", False: "none", None: "unknown"}[e["tex"]], TEXT))
        if e["x"].get("author"):
            rows.append(("By", e["x"]["author"], TEXT))
        for label, value, col in rows:
            y -= 19 * s
            text(px, y, label, DIM)
            text(px + 74 * s, y, fit(str(value), pw - 74 * s), col)
        y -= 18 * s
        busy = job is not None
        y -= 34 * s
        button(px, y, pw, 34 * s, "Import into .blend", ("import",), s, primary=True, enabled=not busy)
        y -= 32 * s
        bw = (pw - 6 * s) / 2
        button(px, y, bw, 26 * s, "Open web page", ("url",), s, enabled=bool(e["page"]))
        button(px + bw + 6 * s, y, bw, 26 * s, "Copy attribution", ("attrib",), s)
        y -= 30 * s
        checkbox(px, y, "Scale to 1 m on import", UI.normalize, ("normalize",), s)

    if job:
        bh = 74 * s
        by = y0 + pad
        rect(px - 4 * s, by - 4 * s, pw + 8 * s, bh + 8 * s, BAR)
        font(12 * s)
        text(px, by + bh - 16 * s, fit(f"{job.status}: {job.entry['name']}", pw), TEXT)
        frac = min(job.done / job.total, 1.0) if job.total else 0.0
        rect(px, by + 30 * s, pw, 12 * s, FIELD)
        rect(px, by + 30 * s, pw * frac, 12 * s, ACCENT)
        font(11 * s)
        size = f"{human(job.done)} / {human(job.total)}" if job.total else human(job.done)
        text(px, by + 12 * s, size, DIM)
        button(px + pw - 80 * s, by, 80 * s, 24 * s, "Cancel", ("cancel",), s)


# ---------------------------------------------------------------- input

def _hit(mx, my):
    for x, y, w, h, action in reversed(UI.hits):
        if x <= mx < x + w and y <= my < y + h:
            return action
    return None


def _apply_search():
    UI.text_changed = 0.0
    if FEED.set(query=UI.text):
        UI.scroll = 0.0
        THUMBS.forget_queue()


def _scroll_by(dy):
    UI.scroll = max(0.0, UI.scroll + dy)


class DSA_OT_browser_modal(bpy.types.Operator):
    bl_idname = "dataset_assets.browser_modal"
    bl_label = "Dataset Browser (input)"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        UI.area_ptr = context.area.as_pointer()
        self._timer = context.window_manager.event_timer_add(0.25, window=context.window)
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set("DEFAULT")
        FEED.request_more()
        return {"RUNNING_MODAL"}

    def _finish(self, context):
        try:
            context.window_manager.event_timer_remove(self._timer)
        except (ReferenceError, ValueError):
            pass
        closed()

    def cancel(self, context):
        self._finish(context)

    def modal(self, context, event):
        if not is_open():
            self._finish(context)
            return {"CANCELLED"}
        region = next((r for r in context.area.regions if r.type == "WINDOW"), None) if context.area else None
        if region is None:
            return {"PASS_THROUGH"}
        if event.type == "TIMER":
            if UI.text_changed and time.time() - UI.text_changed > 0.35:
                _apply_search()
            return {"PASS_THROUGH"}

        mx, my = event.mouse_x - region.x, event.mouse_y - region.y
        inside = 0 <= mx < region.width and 0 <= my < region.height
        UI.mouse = (mx, my)
        t, v = event.type, event.value

        if t in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            if UI.drag:
                start_y, start_scroll = UI.drag
                gx, gy, gw, gh, row_h, content_h = UI.grid
                bar_h = max(30, gh * gh / content_h)
                UI.scroll = start_scroll + (start_y - my) * (content_h - gh) / max(1, gh - bar_h)
            context.area.tag_redraw()
            return {"RUNNING_MODAL"} if inside else {"PASS_THROUGH"}

        if UI.focus and v in {"PRESS", "REPEAT"} and self._type(context, event):
            context.area.tag_redraw()
            return {"RUNNING_MODAL"}

        if t in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"} and inside:
            step = (UI.grid[4] if UI.grid else 150) * 0.5
            _scroll_by(-step if t == "WHEELUPMOUSE" else step)
            context.area.tag_redraw()
            return {"RUNNING_MODAL"}
        if t == "TRACKPADPAN" and inside:
            _scroll_by(event.mouse_y - event.mouse_prev_y)
            context.area.tag_redraw()
            return {"RUNNING_MODAL"}
        if t in {"PAGE_UP", "PAGE_DOWN", "HOME", "END"} and v == "PRESS" and inside:
            gh = UI.grid[3] if UI.grid else 400
            UI.scroll = {"PAGE_UP": UI.scroll - gh * 0.9, "PAGE_DOWN": UI.scroll + gh * 0.9,
                         "HOME": 0.0, "END": 1e12}[t]
            context.area.tag_redraw()
            return {"RUNNING_MODAL"}

        if t == "LEFTMOUSE":
            if v == "RELEASE":
                UI.drag = None
                return {"RUNNING_MODAL"} if inside else {"PASS_THROUGH"}
            if not inside:
                return {"PASS_THROUGH"}
            if v in {"PRESS", "DOUBLE_CLICK"}:
                self._click(context, _hit(mx, my), v == "DOUBLE_CLICK", my)
                context.area.tag_redraw()
                return {"RUNNING_MODAL"}

        if not UI.focus and inside and v == "PRESS" and not UI.fab:
            if t in {"RET", "NUMPAD_ENTER"} and UI.selected:
                self._import()
                return {"RUNNING_MODAL"}
            if event.unicode and event.unicode.isprintable() and not (event.ctrl or event.alt or event.oskey):
                UI.focus = True
                self._type(context, event)
                context.area.tag_redraw()
                return {"RUNNING_MODAL"}
            if t == "F" and event.ctrl:
                UI.focus = True
                context.area.tag_redraw()
                return {"RUNNING_MODAL"}
        return {"RUNNING_MODAL"} if inside and t not in {"WINDOW_DEACTIVATE", "TIMER"} else {"PASS_THROUGH"}

    # -- keyboard into the search field. Returns True if the key was used.
    def _type(self, context, event):
        t = event.type
        if t in {"RET", "NUMPAD_ENTER"}:
            UI.focus = False
            _apply_search()
        elif t == "ESC":
            UI.focus = False
        elif t == "BACK_SPACE":
            if event.ctrl:
                UI.text = UI.text.rstrip()
                UI.text = UI.text[:UI.text.rfind(" ") + 1] if " " in UI.text else ""
            else:
                UI.text = UI.text[:-1]
            UI.text_changed = time.time()
        elif t == "V" and (event.ctrl or event.oskey):
            UI.text += context.window_manager.clipboard.replace("\n", " ")[:200]
            UI.text_changed = time.time()
        elif t == "A" and (event.ctrl or event.oskey):
            UI.text = ""
            UI.text_changed = time.time()
        elif event.unicode and event.unicode.isprintable() and not (event.ctrl or event.alt or event.oskey):
            UI.text += event.unicode
            UI.text_changed = time.time()
        elif t in {"LEFT_SHIFT", "RIGHT_SHIFT", "LEFT_CTRL", "RIGHT_CTRL", "LEFT_ALT", "RIGHT_ALT", "OSKEY"}:
            pass
        else:
            return False
        return True

    def _click(self, context, action, double, my):
        if action != ("search",) and UI.focus:
            UI.focus = False
            if UI.text_changed:
                _apply_search()
        if action is None:
            return
        kind = action[0]
        if kind == "tile":
            e = FEED.items[action[1]]
            UI.selected = (e["src"], e)
            if double:
                self._import()
        elif kind == "fab":
            UI.fab = True
        elif kind == "fab_folder":
            bpy.ops.wm.path_open(filepath=fab.download_dir())
        elif kind == "fab_restart":
            fab.restart()
        elif kind == "source":
            UI.fab = False
            if FEED.set(key=action[1]):
                UI.scroll = 0.0
                THUMBS.forget_queue()
        elif kind == "search":
            UI.focus = True
        elif kind == "clear":
            UI.text = ""
            _apply_search()
        elif kind == "toggle":
            if action[1] == "textured":
                FEED.set(textured=not FEED.textured)
            else:
                FEED.set(commercial=not FEED.commercial)
            UI.scroll = 0.0
            THUMBS.forget_queue()
        elif kind == "retry":
            THUMBS.retry_failed()
            FEED.retry()
        elif kind == "scrollbar":
            _, by, bar_h = action
            if not by <= my < by + bar_h:  # click on the track: jump there
                gx, gy, gw, gh, row_h, content_h = UI.grid
                frac = 1 - (my - gy - bar_h / 2) / max(1, gh - bar_h)
                UI.scroll = max(0.0, min(1.0, frac)) * (content_h - gh)
            UI.drag = (my, UI.scroll)
        elif kind == "import":
            self._import()
        elif kind == "url" and UI.selected:
            bpy.ops.wm.url_open(url=UI.selected[1]["page"])
        elif kind == "attrib" and UI.selected:
            key, e = UI.selected
            context.window_manager.clipboard = jobs.attribution(key, e)["attribution"]
            jobs.message("Attribution copied to the clipboard")
        elif kind == "normalize":
            UI.normalize = not UI.normalize
        elif kind == "cancel" and jobs.CURRENT:
            jobs.CURRENT.cancel = True

    def _import(self):
        if UI.selected:
            key, e = UI.selected
            jobs.start(key, e, UI.normalize)


def fab_tick():
    """Fast timer: keep the Edge window docked over the Fab tab (or hidden)."""
    try:
        return _fab_tick()
    except Exception as ex:  # never let the timer die
        print("dataset_assets fab:", ex)
        return 0.5


def _fab_tick():
    if not UI.fab or not is_open():
        if fab.State.shown:
            fab.follow(None, None)
        return 0.25
    win, area = browser_area()
    region = next((r for r in area.regions if r.type == "WINDOW"), None) if area else None
    if region is None or UI.fab_rect is None:
        return 0.1
    x, y, w, h = UI.fab_rect
    if not fab.WIN:
        fab.start()  # opens the page once in the normal browser
        return 0.5
    got = fab.screen_rect(win, region.x + x, region.y + y, w, h)
    if got is None:
        return 0.1
    rect_, owner = got
    if fab.State.error:
        return 0.5
    if not fab.State.launched:
        fab.start(rect_)  # once; never again until "Restart Fab"
    fab.follow(rect_, owner)
    return 0.04


def draw_tick():
    """Called from the add-on timer: redraw when new results or thumbnails arrived."""
    if UI.area_ptr and not is_open():
        closed()
        return
    if FEED.redraw or THUMBS.redraw:
        FEED.redraw = THUMBS.redraw = False
        tag_redraw()


class DSA_OT_open_browser(bpy.types.Operator):
    bl_idname = "dataset_assets.open_browser"
    bl_label = "Dataset Asset Browser"
    bl_description = ("Open a window to browse Poly Haven, Google Scanned Objects, SimReady, Objaverse "
                      "and ABO, and import models into this .blend")

    def execute(self, context):
        if is_open():
            win, _area = browser_area()
            if win is not None and (win == context.window or raise_window(win)):
                return {"FINISHED"}
            self.report({"INFO"}, "The Dataset Asset Browser is already open in another window")
            return {"CANCELLED"}
        wm = context.window_manager
        win = context.window
        src = max(win.screen.areas, key=lambda a: a.width * a.height)
        before = {w.as_pointer() for w in wm.windows}
        region = next(r for r in src.regions if r.type == "WINDOW")
        with context.temp_override(window=win, screen=win.screen, area=src, region=region):
            bpy.ops.screen.area_dupli("INVOKE_DEFAULT")
        new = next((w for w in wm.windows if w.as_pointer() not in before), None)
        if new is None:
            self.report({"ERROR"}, "Couldn't open a new window")
            return {"CANCELLED"}
        area = new.screen.areas[0]
        area.type = "TEXT_EDITOR"
        space = area.spaces.active
        for attr in ("show_region_header", "show_region_footer", "show_region_ui", "show_region_toolbar"):
            if hasattr(space, attr):
                setattr(space, attr, False)
        region = next(r for r in area.regions if r.type == "WINDOW")
        with context.temp_override(window=new, screen=new.screen, area=area, region=region):
            bpy.ops.dataset_assets.browser_modal("INVOKE_DEFAULT")
        return {"FINISHED"}


_handle = None


def register():
    global _handle
    bpy.utils.register_class(DSA_OT_browser_modal)
    bpy.utils.register_class(DSA_OT_open_browser)
    _handle = bpy.types.SpaceTextEditor.draw_handler_add(draw, (), "WINDOW", "POST_PIXEL")
    bpy.app.timers.register(fab_tick, first_interval=0.5, persistent=True)


def unregister():
    global _handle
    if bpy.app.timers.is_registered(fab_tick):
        bpy.app.timers.unregister(fab_tick)
    if _handle:
        bpy.types.SpaceTextEditor.draw_handler_remove(_handle, "WINDOW")
        _handle = None
    closed()
    bpy.utils.unregister_class(DSA_OT_open_browser)
    bpy.utils.unregister_class(DSA_OT_browser_modal)
