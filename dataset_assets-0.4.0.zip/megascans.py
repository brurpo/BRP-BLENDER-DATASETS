"""Megascans downloads (from Fab) -> something the importer can bring into the .blend.

A Fab download is a zip (or a single model file) with one or more meshes, often several LODs,
and a set of texture maps that FBX files usually don't link. `prepare` unpacks it and writes a
small recipe for importer._run_recipe; `finish` then keeps only the most detailed LOD and
builds Principled materials from the maps. Downloads with no mesh (surfaces, decals) get a
plane with the material.
"""

import json
import os
import re
import zipfile

import bpy

MODEL_EXTS = (".gltf", ".glb", ".fbx", ".usd", ".usda", ".usdc", ".usdz", ".obj", ".abc")
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".exr", ".tga", ".tif", ".tiff", ".bmp")
DOWNLOAD_EXTS = (".zip",) + MODEL_EXTS
LICENSE = "Fab Standard License"
SOURCE_URL = "https://www.fab.com/sellers/Quixel"

# Texture roles, matched against the file name (lowercase, separators turned into "_").
ROLES = (
    ("orm", r"_(orm|arm|ordp|ord)(_|$)"),
    ("opacity", r"(opacity|alpha|_mask(_|$)|cutout)"),
    ("normal", r"(normal|_nrm(_|$)|_nor(_|$)|_n(_|$))"),
    ("base", r"(albedo|basecolor|base_color|diffuse|_color(_|$)|_col(_|$)|_bc(_|$)|_d(_|$))"),
    ("rough", r"(roughness|_rough(_|$)|_r(_|$))"),
    ("gloss", r"(gloss)"),
    ("metal", r"(metalness|metallic|_metal(_|$)|_m(_|$))"),
    ("ao", r"(_ao(_|$)|ambientocclusion|occlusion)"),
    ("height", r"(displacement|height|_disp(_|$))"),
    ("translucency", r"(translucency|transmission|subsurface)"),
    ("cavity", r"cavity"),
    ("specular", r"specular"),
    ("fuzz", r"fuzz"),
)
LOD = re.compile(r"(?:^|[_\-. ])lod[_\-]?(\d+)", re.I)


def _safe_extract(zpath, dest):
    root = os.path.realpath(dest)
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            out = os.path.realpath(os.path.join(root, info.filename))
            if not out.startswith(root + os.sep):
                continue  # entries that would escape the folder
            if info.is_dir():
                os.makedirs(out, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with z.open(info) as src, open(out, "wb") as f:
                while True:
                    chunk = src.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)


def _walk(folder):
    for root, _, files in os.walk(folder):
        for f in files:
            yield os.path.join(root, f)


def _role(path):
    stem = re.sub(r"[\s\-.]+", "_", os.path.splitext(os.path.basename(path))[0].lower())
    for role, pat in ROLES:
        if re.search(pat, stem):
            if role == "normal" and "bump" in stem:
                return "normal_bump"
            return role
    return None


def texture_set(folder):
    """{role: path} for the texture maps in a folder (best file per role)."""
    best = {}
    for p in _walk(folder):
        ext = os.path.splitext(p)[1].lower()
        if ext not in IMAGE_EXTS or "preview" in p.lower() or "thumb" in p.lower():
            continue
        role = _role(p)
        if role is None:
            continue
        # Prefer 8-bit formats for colour maps, EXR for height; larger files are higher resolution.
        rank = (ext == ".exr") == (role == "height"), os.path.getsize(p)
        if role not in best or rank > best[role][0]:
            best[role] = (rank, p)
    out = {r: v[1] for r, v in best.items()}
    if "normal" not in out and "normal_bump" in out:
        out["normal"] = out["normal_bump"]
    return out


def _lod(path_or_name):
    m = LOD.search(os.path.basename(path_or_name))
    return int(m.group(1)) if m else None


def _models(folder):
    """Model files to import: glTF over FBX over the rest, only the lowest LOD of each."""
    files = [p for p in _walk(folder) if p.lower().endswith(MODEL_EXTS)]
    for exts in ((".gltf", ".glb"), (".fbx",), (".usd", ".usda", ".usdc", ".usdz"), (".obj",), (".abc",)):
        pick = [p for p in files if p.lower().endswith(exts)]
        if not pick:
            continue
        groups = {}
        for p in pick:
            key = LOD.sub("", os.path.splitext(os.path.basename(p))[0]).lower()
            groups.setdefault(key, []).append(p)
        out = []
        for group in groups.values():
            out.append(min(group, key=lambda p: (_lod(p) if _lod(p) is not None else -1, len(p))))
        return sorted(out)
    return []


def _metadata(folder):
    """Name, tags and Megascans id from the JSON that comes with the download, if any."""
    for p in _walk(folder):
        if p.lower().endswith(".json") and os.path.getsize(p) < 4_000_000:
            try:
                with open(p, encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, ValueError):
                continue
            if isinstance(data, dict) and ("name" in data or "id" in data or "semanticTags" in data):
                tags = data.get("tags") or []
                return {"name": str(data.get("name") or ""), "id": str(data.get("id") or ""),
                        "tags": ", ".join(t for t in tags if isinstance(t, str))[:300]}
    return {}


JUNK = re.compile(r"^(\d+k|lod\d+|ms|3d|3dplant|plant|surface|decal|atlas|imperfection|brush|fbx|gltf|glb|usd|"
                  r"high|medium|low|mid|raw|nanite|var\d+)$", re.I)


def clean_name(filename):
    """'Mossy_Rock_ujmkebwfa_2K_3d_ms.zip' -> 'Mossy Rock'."""
    stem = os.path.splitext(os.path.basename(filename))[0]
    tokens = [t for t in re.split(r"[_\s]+", stem) if t]
    words = [t for t in tokens if not (JUNK.match(t) and not t[:1].isupper() or re.fullmatch(r"\d+K|LOD\d+", t))]
    if any(t[:1].isupper() for t in words):
        # Megascans ids are short all-lowercase letter runs next to Capitalised name words.
        words = [t for t in words if not (t.islower() and t.isalpha() and 5 <= len(t) <= 10)]
    return " ".join(words) or stem


def prepare(download, dest):
    """Unpack a Fab download into dest. Returns (recipe path, asset name, metadata)."""
    if download.lower().endswith(".zip"):
        _safe_extract(download, dest)
    else:
        import shutil
        shutil.copy(download, dest)
    meta = _metadata(dest)
    name = meta.get("name") or clean_name(download)
    models = _models(dest)
    spec = {"files": [{"path": p, "up": "Y"} for p in models],
            "post": {"folder": dest, "name": name, "plane": not models}}
    if not models and not texture_set(dest):
        raise RuntimeError("the download has no model and no texture maps")
    recipe = os.path.join(dest, "megascans.recipe.json")
    with open(recipe, "w", encoding="utf-8") as f:
        json.dump(spec, f)
    return recipe, name, meta


# ---------------------------------------------------------------- run inside the import

def _image_node(nt, path, non_color, x, y):
    img = bpy.data.images.load(path, check_existing=True)
    if non_color:
        img.colorspace_settings.is_data = True
    n = nt.nodes.new("ShaderNodeTexImage")
    n.image = img
    n.location = (x, y)
    return n


def build_material(name, tex):
    """A Principled material from Megascans maps ({role: path})."""
    mat = bpy.data.materials.new(name)
    nt = mat.node_tree
    bsdf = next(n for n in nt.nodes if n.type == "BSDF_PRINCIPLED")
    y = 300
    if "base" in tex:
        n = _image_node(nt, tex["base"], False, -700, y)
        nt.links.new(n.outputs["Color"], bsdf.inputs["Base Color"])
        y -= 280
    if "opacity" in tex:
        n = _image_node(nt, tex["opacity"], True, -700, y)
        nt.links.new(n.outputs["Color"], bsdf.inputs["Alpha"])
        y -= 280
    if "rough" in tex:
        n = _image_node(nt, tex["rough"], True, -700, y)
        nt.links.new(n.outputs["Color"], bsdf.inputs["Roughness"])
        y -= 280
    elif "gloss" in tex:
        n = _image_node(nt, tex["gloss"], True, -900, y)
        inv = nt.nodes.new("ShaderNodeInvert")
        inv.location = (-450, y)
        nt.links.new(n.outputs["Color"], inv.inputs["Color"])
        nt.links.new(inv.outputs["Color"], bsdf.inputs["Roughness"])
        y -= 280
    if "metal" in tex:
        n = _image_node(nt, tex["metal"], True, -700, y)
        nt.links.new(n.outputs["Color"], bsdf.inputs["Metallic"])
        y -= 280
    if "orm" in tex and ("rough" not in tex or "metal" not in tex):
        n = _image_node(nt, tex["orm"], True, -900, y)
        sep = nt.nodes.new("ShaderNodeSeparateColor")
        sep.location = (-450, y)
        nt.links.new(n.outputs["Color"], sep.inputs["Color"])
        if "rough" not in tex and "gloss" not in tex:
            nt.links.new(sep.outputs["Green"], bsdf.inputs["Roughness"])
        if "metal" not in tex and not os.path.basename(tex["orm"]).lower().count("ordp"):
            nt.links.new(sep.outputs["Blue"], bsdf.inputs["Metallic"])
        y -= 280
    if "normal" in tex:
        n = _image_node(nt, tex["normal"], True, -900, y)
        nm = nt.nodes.new("ShaderNodeNormalMap")
        nm.location = (-450, y)
        nt.links.new(n.outputs["Color"], nm.inputs["Color"])
        nt.links.new(nm.outputs["Normal"], bsdf.inputs["Normal"])
    mat["megascans_maps"] = ", ".join(sorted(tex))
    return mat


def _has_textures(mat):
    return mat is not None and mat.node_tree is not None and any(
        n.type == "TEX_IMAGE" and n.image is not None for n in mat.node_tree.nodes)


def _plane(name, size=2.0):
    h = size / 2
    me = bpy.data.meshes.new(name)
    me.from_pydata([(-h, -h, 0), (h, -h, 0), (h, h, 0), (-h, h, 0)], [], [(0, 1, 2, 3)])
    uv = me.uv_layers.new(name="UVMap")
    for loop, co in zip(uv.data, ((0, 0), (1, 0), (1, 1), (0, 1))):
        loop.uv = co
    ob = bpy.data.objects.new(name, me)
    bpy.context.view_layer.active_layer_collection.collection.objects.link(ob)
    return ob


def finish(objects, post):
    """Drop extra LODs and give untextured meshes the download's material."""
    for o in list(objects):
        lod = _lod(o.name)
        if lod is not None and lod > 0:
            objects.remove(o)
            bpy.data.objects.remove(o, do_unlink=True)
    if post.get("plane"):
        objects.append(_plane(post["name"]))
    tex = texture_set(post["folder"])
    if not tex:
        return
    mat = None
    for o in objects:
        if o.type != "MESH":
            continue
        if not o.material_slots:
            mat = mat or build_material(post["name"], tex)
            o.data.materials.append(mat)
            continue
        for slot in o.material_slots:
            if not _has_textures(slot.material):
                mat = mat or build_material(post["name"], tex)
                slot.material = mat
