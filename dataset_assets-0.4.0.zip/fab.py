"""The Fab tab: Fab's own website in an Edge window docked over the browser, plus auto-import.

Blender can't show web pages, so on Windows this starts Microsoft Edge in app mode (no address
bar or tabs) with its own profile, and keeps that window laid exactly over the Fab tab's area.
You browse, sign in and click Download on Fab yourself; nothing is automated on the site.
Edge saves downloads to a folder this add-on watches. Each finished download is unpacked into
a temporary folder, imported into the .blend (textures packed), and then deleted.

Elsewhere (macOS/Linux) the same page opens in a normal browser window and the watcher still
works if downloads are saved into the shown folder.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time

import bpy

from . import importer, jobs, megascans

START_URL = "https://www.fab.com/sellers/Quixel"
WIN = sys.platform == "win32"


class State:
    cache_dir = ""
    proc = None
    hwnd = None
    owner = None
    container = None       # our window that holds Edge as a child
    shown = False
    rect = None            # last screen rect applied (x, y, w, h)
    want = None            # screen rect the Fab area wants, or None to hide
    started = 0.0
    launched = False       # Edge was started for this Fab session (cleared only by restart())
    launches = 0
    before = set()         # Edge windows that existed before our launch
    error = ""
    queue = []             # finished downloads waiting for import
    seen = {}              # download path -> (size, time first seen at that size)
    current = None         # FabImport in progress
    imported = 0
    last_scan = 0.0


def profile_dir():
    return os.path.join(State.cache_dir, "fab_edge_profile")


def download_dir():
    p = os.path.join(State.cache_dir, "fab_downloads")
    os.makedirs(p, exist_ok=True)
    return p


# ---------------------------------------------------------------- Win32

if WIN:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    user32.SetWindowLongPtrW.restype = ctypes.c_void_p
    user32.SetWindowLongPtrW.argtypes = (wintypes.HWND, ctypes.c_int, ctypes.c_void_p)
    user32.GetWindowLongPtrW.restype = ctypes.c_void_p
    user32.GetWindowLongPtrW.argtypes = (wintypes.HWND, ctypes.c_int)
    user32.SetWindowPos.argtypes = (wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_int, wintypes.UINT)
    EnumProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    GWLP_HWNDPARENT = -8
    WS_POPUP = 0x80000000
    WS_CHILD = 0x40000000
    WS_CLIPCHILDREN = 0x02000000
    WS_EX_TOOLWINDOW = 0x00000080
    GWL_STYLE = -16
    WS_CAPTION = 0x00C00000
    WS_THICKFRAME = 0x00040000
    WS_MINIMIZEBOX = 0x00020000
    WS_MAXIMIZEBOX = 0x00010000
    WS_SYSMENU = 0x00080000
    SWP_NOZORDER = 0x0004
    SWP_NOACTIVATE = 0x0010
    SWP_FRAMECHANGED = 0x0020
    SWP_NOMOVE = 0x0002
    SWP_NOSIZE = 0x0001
    SW_HIDE = 0
    SW_SHOWNOACTIVATE = 4
    WM_CLOSE = 0x0010


def _windows(pred):
    out = []

    @EnumProc
    def visit(hwnd, _):
        if pred(hwnd):
            out.append(hwnd)
        return True

    user32.EnumWindows(visit, 0)
    return out


def _pid(hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


def _cls(hwnd):
    buf = ctypes.create_unicode_buffer(64)
    user32.GetClassNameW(hwnd, buf, 64)
    return buf.value


def blender_hwnd(win):
    """The OS window of a Blender window (matched by client size)."""
    me = os.getpid()
    best = None
    for h in _windows(lambda h: _pid(h) == me and _cls(h) == "GHOST_WindowClass" and user32.IsWindowVisible(h)):
        r = wintypes.RECT()
        user32.GetClientRect(h, ctypes.byref(r))
        d = abs(r.right - win.width) + abs(r.bottom - win.height)
        if best is None or d < best[0]:
            best = (d, h)
    return best[1] if best else None


def screen_rect(win, x, y, w, h):
    """Window-relative Blender pixels (origin bottom-left) -> screen rect (left, top, w, h)."""
    hwnd = blender_hwnd(win)
    if not hwnd:
        return None
    r = wintypes.RECT()
    user32.GetClientRect(hwnd, ctypes.byref(r))
    sx = r.right / max(1, win.width)
    sy = r.bottom / max(1, win.height)
    pt = wintypes.POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    left = pt.x + round(x * sx)
    top = pt.y + round((win.height - (y + h)) * sy)
    return (left, top, round(w * sx), round(h * sy)), hwnd


def find_edge():
    for base in (os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                 os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("LOCALAPPDATA", "")):
        p = os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe")
        if base and os.path.exists(p):
            return p
    return shutil.which("msedge")


def _write_edge_prefs():
    """Point the add-on's Edge profile at the watched folder, with no Save As prompt."""
    path = os.path.join(profile_dir(), "Default", "Preferences")
    try:
        with open(path, encoding="utf-8") as f:
            prefs = json.load(f)
    except (OSError, ValueError):
        prefs = {}
    dl = prefs.setdefault("download", {})
    dl.update({"default_directory": download_dir(), "prompt_for_download": False, "directory_upgrade": True})
    prefs.setdefault("savefile", {})["default_directory"] = download_dir()
    prefs.setdefault("browser", {})["has_seen_welcome_page"] = True
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(prefs, f)


MAX_LAUNCHES = 3      # per Blender session, unless "Restart Fab" is clicked
TITLE_DIP = 33         # height of Edge's own title strip in app mode (device-independent px)
WINDOW_TIMEOUT = 30.0  # seconds to wait for Edge's window after launching


def running():
    """Edge was launched and its window is open (or still expected to appear)."""
    if not State.launched:
        return False
    if State.hwnd is not None:
        return bool(user32.IsWindow(State.hwnd))
    return time.time() - State.started < WINDOW_TIMEOUT


def start(rect=None):
    """Launch Edge once. Never relaunches by itself: closing the window or a failure leaves it
    stopped until restart() (the "Restart Fab" button)."""
    if State.launched or State.error:
        return False
    if not WIN:
        State.launched = True
        bpy.ops.wm.url_open(url=START_URL)
        return False
    if State.launches >= MAX_LAUNCHES:
        State.error = "Fab was restarted too many times; restart Blender to try again"
        return False
    edge = find_edge()
    if not edge:
        State.error = "Microsoft Edge wasn't found"
        return False
    _write_edge_prefs()
    args = [edge, f"--user-data-dir={profile_dir()}", f"--app={START_URL}", "--no-first-run",
            "--no-default-browser-check", "--disable-features=msEdgeSidebarV2,msUndersideButton"]
    if rect:
        x, y, w, h = rect
        args += [f"--window-position={x},{y}", f"--window-size={w},{h}"]
    State.before = set(_edge_windows())
    State.launched = True
    State.launches += 1
    State.started = time.time()
    State.hwnd = State.owner = None
    State.shown = False
    State.rect = None
    State.proc = subprocess.Popen(args, close_fds=True)  # a launcher; it may exit right away
    return True


def stop():
    """Close the Fab window. It stays closed until restart()."""
    if WIN and State.hwnd and user32.IsWindow(State.hwnd):
        user32.PostMessageW(State.hwnd, WM_CLOSE, 0, 0)
    if WIN:
        _drop_container()
    State.proc = State.hwnd = State.owner = None
    State.shown = False


def restart():
    stop()
    State.launched = False
    State.error = ""
    State.launches = 0


def _exe(pid):
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        n = wintypes.DWORD(1024)
        k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n))
        return os.path.basename(buf.value).lower()
    finally:
        k32.CloseHandle(h)


def _edge_windows():
    return _windows(lambda h: _cls(h) == "Chrome_WidgetWin_1" and user32.IsWindowVisible(h)
                    and user32.GetWindowTextLengthW(h) > 0 and _exe(_pid(h)) == "msedge.exe")


def _find_edge_window():
    """The Edge window that appeared after our launch (the launcher's pid is not the browser's)."""
    new = [h for h in _edge_windows() if h not in State.before]
    return new[0] if new else None


def _title_px(hwnd):
    try:
        dpi = user32.GetDpiForWindow(hwnd) or 96
    except AttributeError:
        dpi = 96
    return round(TITLE_DIP * dpi / 96)


def _make_container(owner):
    """A plain window owned by the browser window. Edge becomes its child, so the container's
    edges clip it: Edge's own title strip sits above the container's top and isn't drawn."""
    user32.CreateWindowExW.restype = wintypes.HWND
    user32.CreateWindowExW.argtypes = (wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
                                       ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                       wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, wintypes.LPVOID)
    h = user32.CreateWindowExW(WS_EX_TOOLWINDOW, "STATIC", None, WS_POPUP | WS_CLIPCHILDREN,
                               0, 0, 10, 10, owner, None, None, None)
    return h or None


def _embed(hwnd, container):
    style = user32.GetWindowLongPtrW(hwnd, GWL_STYLE) or 0
    style &= ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU)
    style |= WS_CHILD
    user32.SetWindowLongPtrW(hwnd, GWL_STYLE, style)
    user32.SetParent(hwnd, container)
    user32.SetWindowPos(hwnd, None, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED)


def follow(want, owner):
    """Keep the Edge window on `want` (screen rect) or hidden when want is None."""
    if not WIN or not State.launched:
        return
    if State.hwnd is not None and not user32.IsWindow(State.hwnd):
        # Closed (or Edge quit): don't reopen on our own.
        _drop_container()
        State.hwnd = State.owner = None
        State.shown = False
        State.error = "The Fab window was closed"
        return
    if State.hwnd is None:
        State.hwnd = _find_edge_window()
        if State.hwnd is None:
            if time.time() - State.started > WINDOW_TIMEOUT:
                State.error = "Edge didn't open a window"
            return
    if want is None or owner is None:
        if State.shown:
            user32.ShowWindow(State.container or State.hwnd, SW_HIDE)
            State.shown = False
        return
    if State.owner != owner:
        _drop_container()
        State.container = _make_container(owner)
        if State.container is None:
            State.error = "Couldn't create the Fab panel"
            return
        _embed(State.hwnd, State.container)
        State.owner = owner
        State.rect = None
    if want != State.rect:
        x, y, w, h = want
        t = _title_px(State.hwnd)
        user32.SetWindowPos(State.container, None, x, y, w, h, SWP_NOZORDER | SWP_NOACTIVATE)
        user32.SetWindowPos(State.hwnd, None, 0, -t, w, h + t, SWP_NOZORDER | SWP_NOACTIVATE)
        State.rect = want
    if not State.shown:
        user32.ShowWindow(State.hwnd, SW_SHOWNOACTIVATE)
        user32.ShowWindow(State.container, SW_SHOWNOACTIVATE)
        State.shown = True


def _drop_container():
    if State.container and user32.IsWindow(State.container):
        user32.DestroyWindow(State.container)
    State.container = None


# ---------------------------------------------------------------- downloads

class FabImport:
    """Unpacks one download in a thread; the add-on timer imports it on the main thread."""

    def __init__(self, path):
        self.path = path
        os.makedirs(jobs.TMP_ROOT, exist_ok=True)
        self.tmp = tempfile.mkdtemp(prefix="fab_", dir=jobs.TMP_ROOT)
        self.recipe = self.name = None
        self.meta = {}
        self.error = ""
        self.finished = False
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            self.recipe, self.name, self.meta = megascans.prepare(self.path, self.tmp)
        except Exception as e:
            self.error = str(e)
        self.finished = True
        jobs.redraw = True


def _scan():
    """Find downloads that have finished (no temp extension, size stable for 1.5 s)."""
    now = time.time()
    folder = download_dir()
    present = set()
    for f in os.listdir(folder):
        p = os.path.join(folder, f)
        if not os.path.isfile(p) or not f.lower().endswith(megascans.DOWNLOAD_EXTS):
            continue
        present.add(p)
        size = os.path.getsize(p)
        prev = State.seen.get(p)
        if prev is None or prev[0] != size:
            State.seen[p] = (size, now)
        elif now - prev[1] > 1.5 and p not in State.queue and (State.current is None or State.current.path != p):
            State.queue.append(p)
            State.seen[p] = (size, float("inf"))  # queued once
    for p in list(State.seen):
        if p not in present:
            del State.seen[p]


def tick():
    """Called from the add-on timer: pick up downloads and import them."""
    if not State.cache_dir:
        return
    if time.time() - State.last_scan > 1.0:
        State.last_scan = time.time()
        try:
            _scan()
        except OSError:
            pass
    if State.current is None and State.queue and jobs.CURRENT is None:
        p = State.queue.pop(0)
        jobs.message(f"Unpacking {os.path.basename(p)}…")
        State.current = FabImport(p)
    job = State.current
    if job is None or not job.finished:
        return
    State.current = None
    try:
        if job.error:
            jobs.message(f"Couldn't import {os.path.basename(job.path)}: {job.error}", "ERROR")
            _set_aside(job.path)
            return
        name = job.name[:60]
        info = {
            "dataset": "Quixel Megascans (Fab)",
            "dataset_id": job.meta.get("id") or os.path.basename(job.path),
            "license": megascans.LICENSE,
            "source_url": megascans.SOURCE_URL,
            "attribution": f'"{job.name}" by Quixel Megascans (Fab), {megascans.LICENSE}',
        }
        if job.meta.get("tags"):
            info["tags"] = job.meta["tags"]
        from .window import UI
        try:
            with bpy.context.temp_override(**jobs._main_context()):
                root, packed, failed = importer.import_asset(
                    bpy.context, job.recipe, name, "Y", UI.normalize, info)
                bpy.ops.ed.undo_push(message=f"Import {root.name}")
        except Exception as ex:
            jobs.message(f"Import of {name} failed: {ex}", "ERROR")
            _set_aside(job.path)
            return
        State.imported += 1
        msg = f"Imported {root.name} from Fab: {packed} texture(s) stored in the .blend"
        if root.get("transparency", "opaque") != "opaque":
            msg += f"; transparency: {root['transparency_counts']}"
        jobs.message(msg + (f"; couldn't pack {', '.join(failed[:3])}" if failed else ""),
                     "WARNING" if failed else "INFO")
        try:
            os.remove(job.path)  # the asset lives in the .blend now
        except OSError:
            pass
    finally:
        shutil.rmtree(job.tmp, ignore_errors=True)


def _set_aside(path):
    """Keep a download that failed, out of the watched folder's way."""
    folder = os.path.join(download_dir(), "not imported")
    os.makedirs(folder, exist_ok=True)
    try:
        os.replace(path, os.path.join(folder, os.path.basename(path)))
    except OSError:
        pass


def status():
    if State.current is not None:
        return f"Importing {os.path.basename(State.current.path)}…"
    if State.queue:
        return f"{len(State.queue)} download(s) waiting"
    return f"{State.imported} imported this session" if State.imported else "Waiting for downloads"
