"""Dataset sources, queried page by page.

Nothing is indexed up front. Each source answers `page(query, cursor, flt, cache)` with the
next batch of results, using the dataset's own search where it has one and small cached
chunks (one metadata shard or listing file at a time) where it doesn't.

An entry is a small dict:
  id, name, cat, lic, com (commercial use ok), thumb (url or None), size (bytes or None),
  tex (textured: True / False / None = unknown), page (attribution url), x (source extras)
"""

import csv
import io
import json
import os
import re
import shutil
import threading
import time
import urllib.parse
import zipfile
from concurrent.futures import ThreadPoolExecutor

from . import index, net
from .net import url_path

PAGE = 60  # results per request
DAY = 24 * 3600


def _entry(id, name, cat="", lic="", com=True, thumb=None, size=None, tex=None, page="", x=None):
    return {"id": id, "name": name, "cat": cat, "lic": lic, "com": com, "thumb": thumb,
            "size": size, "tex": tex, "page": page, "x": x or {}}


class Page:
    def __init__(self, items, cursor=None, total=None, note=""):
        self.items = items      # entries for this page
        self.cursor = cursor    # pass back to get the next page; None = no more
        self.total = total      # total matches if the source knows it
        self.note = note        # status text, e.g. how much was searched


def words(q):
    return [w for w in q.lower().split() if w]


def matches(ws, *fields):
    if not ws:
        return True
    text = " ".join(str(f) for f in fields if f).lower()
    return all(w in text for w in ws)


def keep(e, flt):
    if flt.get("textured") and e["tex"] is False:
        return False
    if flt.get("commercial") and not e["com"]:
        return False
    return True


class Source:
    key = ""
    label = ""
    short = ""
    note = ""
    up_axis = "Y"
    has_textures = True  # False: skipped by "All" while the Textured filter is on

    def page(self, query, cursor, flt, cache):
        raise NotImplementedError

    def resolve_thumb(self, e):
        """(thumbnail url, size in bytes or None). Some sources only learn these per asset."""
        return e["thumb"], None

    def download(self, e, dest, prefs, progress, cancel):
        """Download into dest and return the main file's path."""
        raise NotImplementedError


def _cached_json(url, path, max_age=DAY):
    """GET JSON through a small disk cache that expires after max_age seconds."""
    try:
        if time.time() - os.path.getmtime(path) < max_age:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
    except (OSError, ValueError):
        pass
    data = net.get_json(url)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(path + ".tmp", path)
    return data


def _scan_chunks(key, n_chunks, cursor, load, ws, flt, unit, cache):
    """Page through datasets stored as numbered chunks (shards / listing files).

    load(i) returns the entries of chunk i. Chunks already in the local index are searched
    straight from it; missing ones are downloaded in parallel batches, at most one batch per
    call, so a search that matches little still returns quickly and the browser asks again.
    """
    ci, off = cursor or (0, 0)
    done = index.indexed(cache, key)
    out = []
    fetched = False
    while ci < n_chunks and len(out) < PAGE:
        if ci not in done:
            if fetched:
                break
            todo = [c for c in range(ci, n_chunks) if c not in done][:index.PARALLEL]
            index.fill(cache, key, todo, load)
            done.update(todo)
            fetched = True
        need = PAGE - len(out)
        rows = index.query(cache, key, ci, ws, flt, off, need)
        out.extend(rows)
        if len(rows) < need:
            ci, off = ci + 1, 0
        else:
            off += len(rows)
    nxt = (ci, off) if ci < n_chunks else None
    note = f"Searched {min(ci + (1 if off else 0), n_chunks)} of {n_chunks} {unit}" if ws or flt.get("textured") else ""
    return Page(out, nxt, None, note)


def _download_many(files, dest, progress, cancel):
    """files: [(url, relative path, size or None)]. progress(done, total)."""
    total = sum(f[2] or 0 for f in files)
    done = [0]

    def on(n, length):
        done[0] += n
        progress(done[0], total or length)

    for url, rel, _ in files:
        path = os.path.join(dest, *rel.split("/"))
        net.download(url, path, on, cancel)


# ---------------------------------------------------------------- Poly Haven

class PolyHaven(Source):
    key = "polyhaven"
    label = "Poly Haven"
    short = "Poly Haven"
    note = "Hand-made models, CC0"
    API = "https://api.polyhaven.com"

    def _all(self, cache):
        data = _cached_json(f"{self.API}/assets?t=models", os.path.join(cache, "polyhaven", "models.json"))
        out = []
        for id, m in sorted(data.items(), key=lambda kv: -(kv[1].get("download_count") or 0)):
            thumb = m.get("thumbnail_url")
            if thumb:
                thumb = thumb.split("?")[0] + "?width=256&height=256"
            out.append(_entry(
                id, m.get("name") or id, ", ".join(m.get("categories") or []), "CC0", True, thumb, None,
                True, f"https://polyhaven.com/a/{id}",
                {"author": ", ".join((m.get("authors") or {}).keys()), "kw": " ".join(m.get("tags") or [])}))
        return out

    def page(self, query, cursor, flt, cache):
        ws = words(query)
        rows = [e for e in self._all(cache) if keep(e, flt) and matches(ws, e["id"], e["name"], e["cat"], e["x"]["kw"])]
        start = cursor or 0
        end = start + PAGE
        return Page(rows[start:end], end if end < len(rows) else None, len(rows))

    def download(self, e, dest, prefs, progress, cancel):
        files = net.get_json(f"{self.API}/files/{e['id']}")["gltf"]
        res = prefs.get("polyhaven_resolution", "2k")
        pick = files.get(res) or next(files[r] for r in ("2k", "1k", "4k", "8k") if r in files)
        main = pick["gltf"]
        name = main["url"].rsplit("/", 1)[-1]
        lst = [(main["url"], name, main.get("size"))]
        for rel, f in (main.get("include") or {}).items():
            lst.append((f["url"], rel, f.get("size")))
        _download_many(lst, dest, progress, cancel)
        return os.path.join(dest, name)


# ---------------------------------------------------------------- Google Scanned Objects

class Gso(Source):
    key = "gso"
    label = "Google Scanned Objects"
    short = "Scanned Objects"
    note = "~1k real-world scans with photo textures, CC-BY-4.0. Searched on Gazebo Fuel"
    up_axis = "Z"
    API = "https://fuel.gazebosim.org/1.0"

    def page(self, query, cursor, flt, cache):
        n = cursor or 1
        q = "&q=" + urllib.parse.quote(" ".join(words(query))) if words(query) else ""
        arr, headers = net.get_json_headers(f"{self.API}/GoogleResearch/models?per_page={PAGE}&page={n}{q}")
        total = int(headers.get("X-Total-Count") or 0) or None
        out = []
        for m in arr or []:
            id = m.get("name") or ""
            if not id:
                continue
            desc = ((m.get("description") or "").splitlines() or [""])[0].strip()
            thumb = m.get("thumbnail_url")
            out.append(_entry(
                id, desc or id.replace("_", " "), ", ".join(m.get("categories") or []),
                "CC-BY-4.0", True, f"{self.API}{url_path(thumb)}" if thumb else None, m.get("filesize"), True,
                f"https://app.gazebosim.org/GoogleResearch/fuel/models/{id}", {"author": "Google Research"}))
        more = total is not None and n * PAGE < total if total else len(arr or []) == PAGE
        return Page(out, n + 1 if more else None, total)

    def download(self, e, dest, prefs, progress, cancel):
        id = url_path(e["id"])
        zpath = os.path.join(dest, "_download.zip")
        total = e.get("size") or 0
        done = [0]

        def on(n, length):
            done[0] += n
            progress(done[0], total or length)

        net.download(f"{self.API}/GoogleResearch/models/{id}/tip/{id}.zip", zpath, on, cancel)
        _safe_extract(zpath, dest)
        os.remove(zpath)
        # model.mtl expects texture.png next to the mesh; the zip keeps it in materials/textures/.
        tex = os.path.join(dest, "materials", "textures", "texture.png")
        mesh_dir = os.path.join(dest, "meshes")
        if os.path.exists(tex) and not os.path.exists(os.path.join(mesh_dir, "texture.png")):
            shutil.copy(tex, mesh_dir)
        return os.path.join(mesh_dir, "model.obj")


def _safe_extract(zpath, dest):
    root = os.path.realpath(dest)
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            out = os.path.realpath(os.path.join(root, info.filename))
            if not out.startswith(root + os.sep):
                continue  # skip entries that would escape the folder
            if info.is_dir():
                os.makedirs(out, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with z.open(info) as src, open(out, "wb") as f:
                shutil.copyfileobj(src, f)


# ---------------------------------------------------------------- NVIDIA SimReady

class SimReady(Source):
    key = "simready"
    label = "NVIDIA SimReady"
    short = "SimReady"
    note = "~2.7k CAD-quality USD assets, CC-BY-4.0. Size shows once the thumbnail loads"
    API = "https://huggingface.co/api/datasets/nvidia/simready-assets/tree/main"
    RESOLVE = "https://huggingface.co/datasets/nvidia/simready-assets/resolve/main"

    def _entry(self, path):
        return _entry(path, path.replace("_", " "), path.split("_")[0], "CC-BY-4.0", True,
                      page=f"https://huggingface.co/datasets/nvidia/simready-assets/tree/main/{path}",
                      x={"author": "NVIDIA"})

    def _tree(self, path):
        return net.get_json_paged(f"{self.API}/{url_path(path)}?limit=1000&recursive=true")

    def page(self, query, cursor, flt, cache):
        ws = words(query)
        if not ws:
            # Plain browsing: the repository listing, one page at a time.
            items, nxt = net.get_json_link(cursor or f"{self.API}?limit={PAGE}")
            out = [self._entry(i["path"]) for i in items
                   if i.get("type") == "directory" and not i["path"].startswith(".")]
            return Page(out, nxt)
        # Search: the folder names are the only text, so filter the (small) name list.
        path = os.path.join(cache, "simready", "folders.json")
        try:
            fresh = time.time() - os.path.getmtime(path) < DAY
        except OSError:
            fresh = False
        if fresh:
            with open(path, encoding="utf-8") as f:
                names = json.load(f)
        else:
            names = [i["path"] for i in net.get_json_paged(f"{self.API}?limit=1000")
                     if i.get("type") == "directory" and not i["path"].startswith(".")]
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(names, f)
        rows = [self._entry(n) for n in names if matches(ws, n.replace("_", " "))]
        start = cursor if isinstance(cursor, int) else 0
        end = start + PAGE
        return Page(rows[start:end], end if end < len(rows) else None, len(rows))

    def resolve_thumb(self, e):
        if e["thumb"]:
            return e["thumb"], None
        files = [f for f in self._tree(e["id"]) if f.get("type") == "file"]
        paths = [f["path"] for f in files]
        thumb = next((p for p in paths if "/simready_usd/.thumbs/256x256/" in p and p.endswith(".usd.png")), None)
        thumb = thumb or next((p for p in paths if "/.thumbs/" in p and p.endswith("_thumbnail.png")), None)
        size = sum(f.get("size", 0) for f in files if "/.thumbs/" not in f["path"])
        return (f"{self.RESOLVE}/{url_path(thumb)}" if thumb else None), size

    def download(self, e, dest, prefs, progress, cancel):
        prefix = e["id"] + "/"
        files = [f for f in self._tree(e["id"]) if f.get("type") == "file" and "/.thumbs/" not in f["path"]]
        lst = [(f"{self.RESOLVE}/{url_path(f['path'])}", f["path"][len(prefix):], f.get("size")) for f in files]
        _download_many(lst, dest, progress, cancel)
        # The package lists its root USD file(s); the first one is the asset.
        try:
            with open(os.path.join(dest, ".metadata", "com.nvidia.simready.root_usds.json"), encoding="utf-8") as f:
                main = json.load(f)["entries"][0]
        except (OSError, KeyError, IndexError, ValueError):
            main = next((r for _, r, _ in lst
                         if r.startswith("simready_usd/") and r.endswith(".usd") and "/" not in r[13:]), None)
        if not main:
            raise RuntimeError("no root USD file found")
        return os.path.join(dest, *main.split("/"))


# ---------------------------------------------------------------- Objaverse

OBJAVERSE_LICENSES = {
    "by": ("CC-BY-4.0", True), "by-sa": ("CC-BY-SA-4.0", True), "cc0": ("CC0", True),
    "by-nc": ("CC-BY-NC-4.0", False), "by-nc-sa": ("CC-BY-NC-SA-4.0", False),
    "by-nd": ("CC-BY-ND-4.0", False), "by-nc-nd": ("CC-BY-NC-ND-4.0", False),
}


class Objaverse(Source):
    key = "objaverse"
    label = "Objaverse 1.0"
    short = "Objaverse"
    note = "~800k Sketchfab models, mixed quality and licenses. Loaded 5,000 at a time (3.6 MB)"
    RESOLVE = "https://huggingface.co/datasets/allenai/objaverse/resolve/main"
    SHARDS = 160

    def _shard(self, cache, i):
        name = f"000-{i:03d}"
        path = net.cached(f"{self.RESOLVE}/metadata/{name}.json.gz",
                          os.path.join(cache, "objaverse", f"{name}.json.gz"))
        data = json.loads(net.read_gz_text(path))
        os.remove(path)  # the search index keeps what's needed
        out = []
        for uid, m in data.items():
            glb = (m.get("archives") or {}).get("glb") or {}
            lic, com = OBJAVERSE_LICENSES.get(m.get("license") or "", (m.get("license") or "?", False))
            imgs = [im for im in ((m.get("thumbnails") or {}).get("images") or []) if (im.get("width") or 0) >= 256]
            thumb = min(imgs, key=lambda im: im["width"])["url"] if imgs else None
            tc = glb.get("textureCount")
            cats = ", ".join(c.get("name", "") for c in (m.get("categories") or []))
            tags = " ".join(t.get("name", "") for t in (m.get("tags") or []))
            out.append(_entry(
                uid, m.get("name") or uid, cats, lic, com, thumb, glb.get("size"),
                None if tc is None else tc > 0, m.get("viewerUrl") or "",
                {"author": (m.get("user") or {}).get("username", ""), "shard": name, "kw": tags,
                 "faces": glb.get("faceCount")}))
        return out

    def page(self, query, cursor, flt, cache):
        return _scan_chunks(self.key, self.SHARDS, cursor, lambda i: self._shard(cache, i), words(query), flt,
                            "shards", cache)

    def download(self, e, dest, prefs, progress, cancel):
        name = f"{e['id']}.glb"
        size = e.get("size") or 0
        url = f"{self.RESOLVE}/glbs/{e['x']['shard']}/{e['id']}.glb"
        _download_many([(url, name, None)], dest, lambda d, t: progress(d, size or t), cancel)
        return os.path.join(dest, name)


# ---------------------------------------------------------------- Amazon Berkeley Objects

class Abo(Source):
    key = "abo"
    label = "Amazon Berkeley Objects"
    short = "Amazon ABO"
    note = "~8k product models with PBR textures. CC-BY-NC-4.0 (non-commercial only)"
    S3 = "https://amazon-berkeley-objects.s3.amazonaws.com"
    IMG = "https://m.media-amazon.com/images/I"

    def __init__(self):
        self._models = None
        self._lock = threading.Lock()

    def _get(self, cache, rel, keep=True):
        path = os.path.join(cache, "abo", rel.rsplit("/", 1)[-1])
        text = net.read_gz_text(net.cached(f"{self.S3}/{rel}", path))
        if not keep:
            os.remove(path)  # the search index keeps what's needed
        return text

    def _model_table(self, cache):
        with self._lock:
            if self._models is None:
                rows = csv.reader(io.StringIO(self._get(cache, "3dmodels/metadata/3dmodels.csv.gz")))
                next(rows, None)  # header
                self._models = {r[0]: (r[1], int(r[4]) if r[4].isdigit() else 0) for r in rows if len(r) > 4}
            return self._models

    def _listing(self, cache, i):
        h = "0123456789abcdef"[i]

        models = self._model_table(cache)
        out, seen = [], set()
        for line in self._get(cache, f"listings/metadata/listings_{h}.json.gz", keep=False).splitlines():
            if "3dmodel_id" not in line:
                continue
            try:
                v = json.loads(line)
            except ValueError:
                continue
            mid = v.get("3dmodel_id")
            if not mid or mid in seen or mid not in models:
                continue
            seen.add(mid)
            names = v.get("item_name") or []
            en = next((n for n in names if str(n.get("language_tag", "")).startswith("en")), names[0] if names else {})
            kind = ((v.get("product_type") or [{}])[0]).get("value", "").lower().replace("_", " ")
            brand = ((v.get("brand") or [{}])[0]).get("value", "")
            img = v.get("main_image_id")
            path, n_tex = models[mid]
            out.append(_entry(
                mid, en.get("value") or mid, kind, "CC-BY-NC-4.0", False,
                f"{self.IMG}/{url_path(img)}._SL256_.jpg" if img else None, None, n_tex > 0,
                "https://amazon-berkeley-objects.s3.amazonaws.com/index.html",
                {"path": path, "author": brand, "kw": brand}))
        return out

    def page(self, query, cursor, flt, cache):
        if flt.get("commercial"):
            return Page([], None, 0, "ABO is non-commercial only (CC-BY-NC-4.0)")
        return _scan_chunks(self.key, 16, cursor, lambda i: self._listing(cache, i), words(query), flt,
                            "listing files", cache)

    def download(self, e, dest, prefs, progress, cancel):
        name = f"{e['id']}.glb"
        _download_many([(f"{self.S3}/3dmodels/original/{e['x']['path']}", name, None)], dest, progress, cancel)
        return os.path.join(dest, name)


# ---------------------------------------------------------------- Smithsonian Open Access 3D

class Smithsonian(Source):
    key = "smithsonian"
    label = "Smithsonian Open Access 3D"
    short = "Smithsonian"
    note = "~3.5k museum scans (skeletons, fossils, busts, artifacts), CC0"
    ROWS = ("https://datasets-server.huggingface.co/rows?dataset=suvadityamuk/smithsonian-open-access-3d"
            "&config=metadata&split=train")
    WEEK = 7 * DAY

    def __init__(self):
        self._rows = None
        self._lock = threading.Lock()

    @staticmethod
    def _compact(r):
        """Keep the fields the browser needs (the full rows are ~20 KB each)."""
        lst = lambda k: [str(v) for v in (r.get(k) or []) if v]
        kw = lst("scientific_name") + lst("set_name") + lst("object_type") + lst("culture") + lst("place")             + lst("tax_class") + lst("tax_order") + [r.get("title") or "", r.get("unit_code") or ""]
        return {"id": r["package_id"], "name": r.get("package_title") or r.get("title") or r["package_id"],
                "cat": ", ".join(lst("topic")), "page": r.get("record_link") or r.get("voyager_url") or "",
                "author": r.get("data_source") or "", "kw": " ".join(kw), "mesh": r.get("mesh_url"),
                "size": r.get("size_bytes"), "tex": (r.get("gltf_textures") or 0) > 0}

    def _all(self, cache):
        with self._lock:
            if self._rows is not None:
                return self._rows
            path = os.path.join(cache, "smithsonian", "catalog.json")
            try:
                if time.time() - os.path.getmtime(path) < self.WEEK:
                    with open(path, encoding="utf-8") as f:
                        self._rows = json.load(f)
                        return self._rows
            except (OSError, ValueError):
                pass
            # One-time catalog: the community copy lists exactly the CC0 packages with their metadata.
            first = net.get_json(f"{self.ROWS}&offset=0&length=100")
            total = first.get("num_rows_total") or len(first["rows"])
            with ThreadPoolExecutor(8) as ex:
                pages = [first] + list(ex.map(lambda o: net.get_json(f"{self.ROWS}&offset={o}&length=100"),
                                               range(100, total, 100)))
            rows = [self._compact(x["row"]) for p in pages for x in p["rows"]]
            rows = [r for r in rows if r["mesh"]]
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path + ".tmp", "w", encoding="utf-8") as f:
                json.dump(rows, f)
            os.replace(path + ".tmp", path)
            self._rows = rows
            return rows

    def page(self, query, cursor, flt, cache):
        ws = words(query)
        rows = []
        for r in self._all(cache):
            e = _entry(r["id"], r["name"], r["cat"], "CC0", True,
                       f"https://3d-api.si.edu/content/document/3d_package:{r['id']}/scene-image-low.jpg",
                       r["size"], r["tex"], r["page"], {"author": r["author"], "kw": r["kw"], "mesh": r["mesh"]})
            if keep(e, flt) and matches(ws, e["name"], e["cat"], r["kw"]):
                rows.append(e)
        start = cursor or 0
        end = start + PAGE
        return Page(rows[start:end], end if end < len(rows) else None, len(rows))

    def download(self, e, dest, prefs, progress, cancel):
        url = e["x"]["mesh"]
        name = url.rsplit("/", 1)[-1].split("?")[0] or f"{e['id']}.glb"
        _download_many([(url, name, e.get("size"))], dest, progress, cancel)
        return os.path.join(dest, name)


def _recipe(dest, spec):
    """Write an import recipe (see importer._run_recipe) and return its path."""
    path = os.path.join(dest, "import.recipe.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(spec, f)
    return path


def _filter_local(rows, query, cursor, flt):
    ws = words(query)
    hits = [e for e in rows if keep(e, flt) and matches(ws, e["name"], e["cat"], e["x"].get("kw"))]
    start = cursor or 0
    end = start + PAGE
    return Page(hits[start:end], end if end < len(hits) else None, len(hits))


# ---------------------------------------------------------------- BodyParts3D

class BodyParts3D(Source):
    key = "bodyparts3d"
    label = "BodyParts3D (DBCLS)"
    short = "BodyParts3D"
    note = "1,258 human anatomy parts (organs, bones, vessels). Untextured. CC-BY-SA-2.1-JP"
    up_axis = "Z"
    has_textures = False
    ZIP = "https://dbarchive.biosciencedbc.jp/data/bodyparts3d/LATEST/partof_BP3D_4.0_obj_99.zip"
    LIC = "CC-BY-SA-2.1-JP"

    def __init__(self):
        self._rows = None
        self._cache = ""
        self._lock = threading.Lock()

    def _zip(self):
        return net.cached(self.ZIP, os.path.join(self._cache, "bodyparts3d", "partof_BP3D_4.0_obj_99.zip"))

    def _all(self, cache):
        with self._lock:
            self._cache = cache
            if self._rows is None:
                rows = []
                with zipfile.ZipFile(self._zip()) as z:
                    for info in z.infolist():
                        if not info.filename.lower().endswith(".obj"):
                            continue
                        with z.open(info) as f:
                            head = f.read(2048).decode("latin-1", "replace")
                        meta = dict(re.findall(r"^# ([A-Za-z ()]+?) : (.*)$", head, re.M))
                        fid = os.path.splitext(os.path.basename(info.filename))[0]
                        rows.append(_entry(
                            fid, meta.get("English name", fid).strip(), "human anatomy", self.LIC, True, None,
                            info.file_size, False, "https://dbarchive.biosciencedbc.jp/en/bodyparts3d/",
                            {"author": "DBCLS", "kw": f"{meta.get('Concept ID', '')} anatomy body human",
                             "member": info.filename}))
                rows.sort(key=lambda e: e["name"].lower())
                self._rows = rows
            return self._rows

    def page(self, query, cursor, flt, cache):
        return _filter_local(self._all(cache), query, cursor, flt)

    def download(self, e, dest, prefs, progress, cancel):
        with zipfile.ZipFile(self._zip()) as z:
            out = os.path.join(dest, os.path.basename(e["x"]["member"]))
            with z.open(e["x"]["member"]) as src, open(out, "wb") as f:
                shutil.copyfileobj(src, f)
        progress(e["size"] or 1, e["size"] or 1)
        # Coordinates are millimetres, Z up.
        return _recipe(dest, {"files": [{"path": out, "up": "Z", "scale": 0.001}]})


# ---------------------------------------------------------------- Z-Anatomy

_ZA_LIST = r'''
import bpy, json, sys
out = []
def clean(n):
    return n.split(":", 1)[-1].rstrip("'")
for sysc in bpy.context.scene.collection.children:
    n = sysc.name
    if not (n[:1].isdigit() and n[1:2] == ":") or n.startswith("0:"):
        continue
    def walk(c, path, depth):
        meshes = sorted({o.name for o in c.all_objects if o.type == "MESH"})
        if meshes and depth <= 2:
            out.append({"kind": "group", "name": clean(c.name), "cat": " / ".join(path), "objects": meshes})
        for ch in c.children:
            walk(ch, path + [clean(c.name)], depth + 1)
    walk(sysc, [], 0)
    for o in sysc.all_objects:
        if o.type == "MESH":
            out.append({"kind": "part", "name": o.name, "cat": clean(n), "objects": [o.name],
                        "kw": " ".join(clean(c.name) for c in o.users_collection)})
seen, rows = set(), []
for r in out:
    k = (r["kind"], r["name"], len(r["objects"]))
    if k not in seen:
        seen.add(k)
        rows.append(r)
json.dump(rows, open(sys.argv[sys.argv.index("--") + 1], "w", encoding="utf-8"))
'''


class ZAnatomy(Source):
    key = "zanatomy"
    label = "Z-Anatomy atlas"
    short = "Z-Anatomy"
    note = ("Whole-body anatomy atlas: systems, groups and single parts. Flat colours, no textures. "
            "First use downloads 130 MB. CC-BY-4.0 (Zenodo)")
    up_axis = "Z"
    has_textures = False
    ZIP = "https://zenodo.org/records/4953712/files/Z-Anatomy.zip?download=1"
    LIC = "CC-BY-4.0"

    def __init__(self):
        self._rows = None
        self._cache = ""
        self._lock = threading.Lock()

    def _blend(self):
        d = os.path.join(self._cache, "zanatomy")
        blend = os.path.join(d, "Z-Anatomy.blend")
        if not os.path.exists(blend):
            zpath = net.cached(self.ZIP, os.path.join(d, "Z-Anatomy.zip"))
            with zipfile.ZipFile(zpath) as z:
                name = next(n for n in z.namelist() if n.endswith("Z-Anatomy.blend"))
                with z.open(name) as src, open(blend + ".part", "wb") as f:
                    shutil.copyfileobj(src, f)
            os.replace(blend + ".part", blend)
            os.remove(zpath)
        return blend

    def _all(self, cache):
        import subprocess
        import bpy
        with self._lock:
            self._cache = cache
            if self._rows is not None:
                return self._rows
            path = os.path.join(cache, "zanatomy", "catalog.json")
            if not os.path.exists(path):
                blend = self._blend()
                script = os.path.join(cache, "zanatomy", "list.py")
                with open(script, "w", encoding="utf-8") as f:
                    f.write(_ZA_LIST)
                # Reading the 360 MB .blend in a background Blender keeps this window responsive.
                subprocess.run([bpy.app.binary_path, "-b", "--factory-startup", blend, "--python", script,
                                "--", path], check=True, capture_output=True, timeout=900,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            with open(path, encoding="utf-8") as f:
                raw = json.load(f)
            rows = []
            for i, r in enumerate(raw):
                group = r["kind"] == "group"
                name = f"{r['name']} ({len(r['objects'])} parts)" if group else r["name"]
                rows.append(_entry(
                    f"{r['kind']}:{i}", name, r["cat"] or r["name"], self.LIC, True, None, None, False,
                    "https://zenodo.org/records/4953712",
                    {"author": "Z-Anatomy", "kw": r.get("kw", "") + " anatomy human body",
                     "objects": r["objects"]}))
            groups = [e for e in rows if e["id"].startswith("group:")]
            parts = sorted((e for e in rows if e["id"].startswith("part:")), key=lambda e: e["name"].lower())
            self._rows = groups + parts
            return self._rows

    def page(self, query, cursor, flt, cache):
        return _filter_local(self._all(cache), query, cursor, flt)

    def download(self, e, dest, prefs, progress, cancel):
        blend = self._blend()
        progress(1, 1)
        return _recipe(dest, {"append": {"blend": blend, "objects": e["x"]["objects"]}})


# ---------------------------------------------------------------- VRoid / VRM samples

class VrmSamples(Source):
    key = "vrm"
    label = "VRM sample avatars (GitHub)"
    short = "VRM avatars"
    note = "18 anime-style VRoid / VRM sample avatars. Terms vary per model (VRoid samples: pixiv's terms)"
    REPO = "madjin/vrm-samples"

    def _all(self, cache):
        data = _cached_json(f"https://api.github.com/repos/{self.REPO}/git/trees/HEAD?recursive=1",
                            os.path.join(cache, "vrm", "tree.json"), 7 * DAY)
        rows = []
        for t in data.get("tree", []):
            p = t.get("path", "")
            if not p.lower().endswith(".vrm"):
                continue
            name = os.path.splitext(os.path.basename(p))[0].replace("_", " ")
            vroid = p.startswith("vroid/")
            thumb = (f"https://raw.githubusercontent.com/{self.REPO}/HEAD/Seed-san/screenshot/screenshot.png"
                     if p.startswith("Seed-san/") else None)
            rows.append(_entry(
                p, name, "anime avatar" if vroid else "avatar",
                "VRoid sample terms" if vroid else "see source", False, thumb, t.get("size"), True,
                f"https://github.com/{self.REPO}/blob/HEAD/{url_path(p)}",
                {"author": "pixiv VRoid" if vroid else "", "kw": "vrm anime vroid character human " + p}))
        return rows

    def page(self, query, cursor, flt, cache):
        return _filter_local(self._all(cache), query, cursor, flt)

    def download(self, e, dest, prefs, progress, cancel):
        name = os.path.splitext(os.path.basename(e["id"]))[0] + ".glb"  # VRM is a glTF binary
        _download_many([(f"https://github.com/{self.REPO}/raw/HEAD/{url_path(e['id'])}", name, e["size"])],
                       dest, progress, cancel)
        return os.path.join(dest, name)


# ---------------------------------------------------------------- Objaverse-XL rigged & animated subset

SKETCHFAB_LICENSES = {
    "CC Attribution": ("CC-BY-4.0", True), "CC0 Public Domain": ("CC0", True),
    "CC Attribution-ShareAlike": ("CC-BY-SA-4.0", True), "CC Attribution-NoDerivs": ("CC-BY-ND-4.0", True),
    "CC Attribution-NonCommercial": ("CC-BY-NC-4.0", False),
    "CC Attribution-NonCommercial-ShareAlike": ("CC-BY-NC-SA-4.0", False),
    "CC Attribution-NonCommercial-NoDerivs": ("CC-BY-NC-ND-4.0", False),
}


class RiggedXL(Source):
    key = "rigged"
    label = "Objaverse-XL rigged & animated"
    short = "Rigged"
    note = ("7,373 models with a skeleton and animation. Names and licences load per tile from Sketchfab; "
            "XL-only files have no name or licence")
    BASE = "https://huggingface.co/datasets/Linzhan/Objaverse-XL-Rigged-Animated/resolve/main"

    def __init__(self):
        self._rows = None
        self._meta = {}       # Sketchfab details already looked up: id -> {name, lic, com, author, kw}
        self._meta_path = ""
        self._lock = threading.Lock()

    def _apply(self, e):
        m = self._meta.get(e["id"])
        if m:
            e["name"], e["lic"], e["com"] = m["name"], m["lic"], m["com"]
            e["x"]["author"] = m["author"]
            e["x"]["kw"] = e["x"]["kw"].split(" | ")[0] + " | " + m["kw"]

    def _all(self, cache):
        with self._lock:
            if self._rows is None:
                self._meta_path = os.path.join(cache, "rigged", "sketchfab.json")
                try:
                    with open(self._meta_path, encoding="utf-8") as f:
                        self._meta = json.load(f)
                except (OSError, ValueError):
                    self._meta = {}
                path = os.path.join(cache, "rigged", "metadata.csv")
                if not os.path.exists(path) or time.time() - os.path.getmtime(path) > 7 * DAY:
                    net.download(f"{self.BASE}/metadata.csv", path)
                rows = []
                with open(path, encoding="utf-8") as f:
                    for r in csv.DictReader(f):
                        sk = r["id_family"] == "objaverse_sketchfab"
                        rows.append(_entry(
                            r["object_id"], r["object_id"] if sk else os.path.basename(r["file"]),
                            f"rigged, {r['num_joints']} joints, {r['num_animations']} clip(s)",
                            "loading…" if sk else "unknown", False, None, int(r["size_bytes"] or 0) or None,
                            None, f"https://sketchfab.com/3d-models/{r['object_id']}" if sk else
                            "https://huggingface.co/datasets/Linzhan/Objaverse-XL-Rigged-Animated",
                            {"file": r["file"], "sketchfab": sk, "kw": f"rigged animated {r['generator']}",
                             "author": ""}))
                # Sketchfab ones first: they get names, thumbnails and licences.
                rows.sort(key=lambda e: not e["x"]["sketchfab"])
                for e in rows:
                    self._apply(e)
                self._rows = rows
            return self._rows

    def page(self, query, cursor, flt, cache):
        return _filter_local(self._all(cache), query, cursor, flt)

    def resolve_thumb(self, e):
        if not e["x"].get("sketchfab"):
            return None, e["size"]
        # Sketchfab's public model API (no account needed) fills in what the dataset table lacks.
        m = net.get_json(f"https://api.sketchfab.com/v3/models/{e['id']}")
        label = (m.get("license") or {}).get("label", "")
        lic, com = SKETCHFAB_LICENSES.get(label, (label or "unknown", False))
        with self._lock:
            self._meta[e["id"]] = {
                "name": m.get("name") or e["name"], "lic": lic, "com": com,
                "author": (m.get("user") or {}).get("displayName", ""),
                "kw": " ".join(t.get("name", "") for t in m.get("tags") or [])}
            self._apply(e)
            if self._meta_path:
                os.makedirs(os.path.dirname(self._meta_path), exist_ok=True)
                with open(self._meta_path + ".tmp", "w", encoding="utf-8") as f:
                    json.dump(self._meta, f)
                os.replace(self._meta_path + ".tmp", self._meta_path)
        imgs = [i for i in ((m.get("thumbnails") or {}).get("images") or []) if (i.get("width") or 0) >= 200]
        thumb = min(imgs, key=lambda i: i["width"])["url"] if imgs else None
        return thumb, e["size"]

    def download(self, e, dest, prefs, progress, cancel):
        name = os.path.basename(e["x"]["file"])
        _download_many([(f"{self.BASE}/{url_path(e['x']['file'])}", name, e["size"])], dest, progress, cancel)
        return os.path.join(dest, name)


ALL = [PolyHaven(), Gso(), SimReady(), Smithsonian(), Objaverse(), Abo(), RiggedXL(), VrmSamples(),
       ZAnatomy(), BodyParts3D()]
BY_KEY = {s.key: s for s in ALL}
