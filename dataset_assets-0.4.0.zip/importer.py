"""Import a downloaded asset into the open .blend and pack everything it needs into it."""

import os

import bpy
from mathutils import Matrix, Vector

from .transparency import apply_usd_mdl, fix_transparency

USD_EXTS = (".usd", ".usda", ".usdc", ".usdz")


def _append_from_blend(blend, names):
    """Append objects by name from a .blend; drop anything they dragged along (parents etc.)."""
    before = set(bpy.data.objects)
    with bpy.data.libraries.load(blend, link=False) as (src, dst):
        wanted = set(src.objects)
        dst.objects = [n for n in names if n in wanted]
    got = [o for o in dst.objects if o is not None]
    if not got:
        raise RuntimeError("none of the objects were found in the .blend")
    coll = bpy.context.view_layer.active_layer_collection.collection
    keep = set(got)
    for o in got:
        coll.objects.link(o)
        mw = o.matrix_world.copy()  # stored in the file, valid even with an unlinked parent
        if o.parent is not None and o.parent not in keep:
            o.parent = None
            o.matrix_world = mw
        for m in list(o.modifiers):
            if m.type == "BOOLEAN":
                o.modifiers.remove(m)
    for o in [o for o in bpy.data.objects if o not in before and o not in keep]:
        bpy.data.objects.remove(o, do_unlink=True)


def _run_recipe(path):
    """A small JSON recipe written by a source: several files, unit scale, layout, .blend append."""
    import json
    with open(path, encoding="utf-8") as f:
        spec = json.load(f)
    if spec.get("append"):
        _append_from_blend(spec["append"]["blend"], spec["append"]["objects"])
    start = set(bpy.data.objects)
    x = 0.0
    for item in spec.get("files", []):
        before = set(bpy.data.objects)
        _run_importer(item["path"], item.get("up", "Y"))
        new = [o for o in bpy.data.objects if o not in before]
        tops = [o for o in new if o.parent is None]
        scale = item.get("scale", 1.0)
        if scale != 1.0:
            for o in tops:
                o.matrix_world = Matrix.Diagonal((scale, scale, scale, 1.0)) @ o.matrix_world
        if spec.get("layout") == "row" and tops:
            bpy.context.view_layer.update()
            xs = [(o.matrix_world @ Vector(c)).x for o in new if o.type == "MESH" for c in o.bound_box]
            if xs:
                shift = x - min(xs)
                for o in tops:
                    o.matrix_world = Matrix.Translation((shift, 0, 0)) @ o.matrix_world
                x += max(xs) - min(xs) + 0.1 * max(1e-3, max(xs) - min(xs))
    if spec.get("post"):  # Megascans: keep LOD0, build materials from the texture maps
        from . import megascans
        megascans.finish([o for o in bpy.data.objects if o not in start], spec["post"])


def _run_importer(path, up_axis):
    ext = os.path.splitext(path)[1].lower()
    if path.endswith(".recipe.json"):
        _run_recipe(path)
    elif ext in USD_EXTS:
        # Scene instancing would put the real mesh in a hidden prototype collection.
        kw = {"import_cameras": False, "import_lights": False}
        props = bpy.ops.wm.usd_import.get_rna_type().properties
        if "support_scene_instancing" in props:
            kw["support_scene_instancing"] = False
        bpy.ops.wm.usd_import(filepath=path, **kw)
    elif ext in (".gltf", ".glb", ".vrm"):  # VRM is glTF; its toon materials fall back to PBR
        bpy.ops.import_scene.gltf(filepath=path)
    elif ext == ".obj":
        # OBJ has no axis convention. Most files are Y-up; Google Scanned Objects are Z-up.
        if up_axis == "Z":
            bpy.ops.wm.obj_import(filepath=path, forward_axis="Y", up_axis="Z")
        else:
            bpy.ops.wm.obj_import(filepath=path)
    elif ext == ".fbx":
        bpy.ops.import_scene.fbx(filepath=path)
    elif ext == ".abc":
        bpy.ops.wm.alembic_import(filepath=path)
    elif ext == ".ply":
        bpy.ops.wm.ply_import(filepath=path)
    elif ext == ".stl":
        bpy.ops.wm.stl_import(filepath=path)
    else:
        raise RuntimeError(f"unsupported format {ext}")


def _layer_collection(lc, coll):
    if lc.collection == coll:
        return lc
    for child in lc.children:
        found = _layer_collection(child, coll)
        if found:
            return found
    return None


def _make_instances_real(context, objs):
    instancers = [o for o in objs if o.instance_type == "COLLECTION" and o.instance_collection]
    if not instancers:
        return
    protos = {o.instance_collection for o in instancers}
    bpy.ops.object.select_all(action="DESELECT")
    for o in instancers:
        o.select_set(True)
    context.view_layer.objects.active = instancers[0]
    bpy.ops.object.duplicates_make_real(use_base_parent=True, use_hierarchy=True)
    for o in instancers:
        o.instance_type = "NONE"
    for coll in protos:
        if coll.users <= 1:  # only the import used it
            for o in list(coll.objects):
                bpy.data.objects.remove(o, do_unlink=True)
            bpy.data.collections.remove(coll)


def import_asset(context, path, name, up_axis="Y", normalize=False, info=None):
    """Import `path`, group it under an empty at the 3D cursor and pack its images.

    Returns (root object, number of images stored in the .blend, images that could not be packed).
    """
    if context.object and context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    before_objs = set(bpy.data.objects)
    before_imgs = set(bpy.data.images)
    before_colls = set(bpy.data.collections)

    coll = bpy.data.collections.new(name)
    context.scene.collection.children.link(coll)
    prev_active = context.view_layer.active_layer_collection
    context.view_layer.active_layer_collection = _layer_collection(context.view_layer.layer_collection, coll)
    try:
        _run_importer(path, up_axis)
    finally:
        context.view_layer.active_layer_collection = prev_active

    new = [o for o in bpy.data.objects if o not in before_objs]
    _make_instances_real(context, new)
    new = [o for o in bpy.data.objects if o not in before_objs]
    for o in list(new):
        if o.type in ("CAMERA", "LIGHT", "LIGHT_PROBE", "SPEAKER"):
            bpy.data.objects.remove(o, do_unlink=True)
            new.remove(o)
    # Importers that make their own collections: move everything into ours.
    for o in new:
        if coll not in o.users_collection:
            coll.objects.link(o)
        for c in list(o.users_collection):
            if c != coll and c not in before_colls:
                c.objects.unlink(o)
    for c in bpy.data.collections:
        if c not in before_colls and c != coll and not c.objects and not c.children:
            bpy.data.collections.remove(c)
    if not any(o.type == "MESH" for o in new):
        raise RuntimeError("the file has no mesh geometry")

    # Root empty: bottom centre of the asset sits on the 3D cursor.
    context.view_layer.update()
    lo = Vector((1e30, 1e30, 1e30))
    hi = Vector((-1e30, -1e30, -1e30))
    for o in new:
        if o.type == "MESH" and len(o.data.vertices):
            for c in o.bound_box:
                w = o.matrix_world @ Vector(c)
                lo = Vector(map(min, lo, w))
                hi = Vector(map(max, hi, w))
    size = hi - lo
    s = 1.0 / max(size.x, size.y, size.z, 1e-9) if normalize else 1.0
    offset = Vector((-(lo.x + hi.x) / 2, -(lo.y + hi.y) / 2, -lo.z))

    root = bpy.data.objects.new(name, None)
    root.empty_display_type = "PLAIN_AXES"
    root.empty_display_size = max(size.x, size.y, size.z, 1e-3) * 0.6
    coll.objects.link(root)
    for o in new:
        if o.parent is None:
            o.parent = root
    root.matrix_world = (
        Matrix.Translation(context.scene.cursor.location)
        @ Matrix.Diagonal((s, s, s, 1.0))
        @ Matrix.Translation(offset)
    )
    for k, v in (info or {}).items():
        root[k] = v

    # Alpha / opacity wiring and EEVEE settings. glTF's alphaMode is authoritative, so its
    # base color alpha is only used when the file asked for it.
    ext = os.path.splitext(path)[1].lower()
    if ext in USD_EXTS:
        # Omniverse/SimReady glass and opacity live in MDL shaders the importer skips.
        mdl = apply_usd_mdl(path, new)
        if mdl:
            root["usd_mdl_fixes"] = "; ".join(f"{m}: {', '.join(c)}" for m, c in mdl.items())[:2000]
    # ABO marks every material OPAQUE, even glass whose alpha is baked into the base color.
    abo = "Amazon" in str((info or {}).get("dataset", ""))
    report = fix_transparency(new + [root], use_basecolor_alpha=abo or ext not in (".gltf", ".glb"))
    counts = report["assets"].get(root.name, {}).get("counts", {})
    root["transparency_counts"] = ", ".join(f"{k}: {v}" for k, v in counts.items() if v)
    root["transparency_repairs"] = report["repaired"]

    packed, failed = pack_images([i for i in bpy.data.images if i not in before_imgs])

    bpy.ops.object.select_all(action="DESELECT")
    root.select_set(True)
    context.view_layer.objects.active = root
    return root, packed, failed


def pack_images(images):
    """Pack file-based images into the .blend so nothing points at the temp folder.

    Returns (images now inside the .blend, including ones the importer embedded itself, failures).
    """
    failed = []
    for img in images:
        if img.source not in ("FILE", "SEQUENCE", "TILED") or img.packed_file or not img.filepath:
            continue
        try:
            img.pack()
        except RuntimeError:
            failed.append(img.name)
    # Point packed images at a neutral relative path instead of the deleted temp folder.
    for img in images:
        if img.packed_file and img.filepath and not img.filepath.startswith("//"):
            base = os.path.basename(bpy.path.abspath(img.filepath)) or img.name
            img.filepath_raw = "//textures/" + base
    return sum(1 for img in images if img.packed_file), failed
