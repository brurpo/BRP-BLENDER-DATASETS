"""Self-update from the public GitHub release repository.

Installed from a zip, an extension isn't linked to any repository, so Blender never offers it
updates. This module does it instead: shortly after Blender starts it reads the release
repository's index.json, and if it lists a newer version it downloads that zip, checks its size
and SHA-256 against the index, and installs it over this one with Blender's own extension
installer. Installs that came from a remote repository are left to Blender.

It runs only with Online Access on, never in background mode, and only installs while no import
is running and the browser window is closed (otherwise it waits).
"""

import hashlib
import os
import re
import tempfile
import threading
import time
import urllib.parse

import bpy

from . import net

# Overridable for testing against a local copy of the release repository.
INDEX_URL = os.environ.get("DATASET_ASSETS_UPDATE_URL") or \
    "https://raw.githubusercontent.com/brurpo/BRP-BLENDER-DATASETS/main/index.json"
PKG_ID = "dataset_assets"
FIRST_CHECK = 10.0      # seconds after startup
NOTE = os.path.join(tempfile.gettempdir(), "dataset_assets_update", "updated.txt")
RECHECK = 6 * 3600.0    # while Blender stays open


class State:
    status = ""          # shown in the preferences
    latest = None        # newest version seen on GitHub
    ready = None         # (version, zip path) downloaded and verified, waiting to install
    busy = False
    last_check = 0.0
    installed = None     # version installed this session


def installed_version():
    with open(os.path.join(os.path.dirname(__file__), "blender_manifest.toml"), encoding="utf-8") as f:
        return re.search(r'^version\s*=\s*"([^"]+)"', f.read(), re.M).group(1)


def _key(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3])


def _repo():
    """(repo module, repo) this add-on was installed into, or (None, None) for a legacy add-on."""
    parts = __package__.split(".")
    if len(parts) < 3 or parts[0] != "bl_ext":
        return None, None
    for r in bpy.context.preferences.extensions.repos:
        if r.module == parts[1]:
            return parts[1], r
    return parts[1], None


def _prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except (KeyError, AttributeError):
        return None


def can_self_update():
    module, repo = _repo()
    if module is None:
        return False, "Installed as a legacy add-on; reinstall the zip to get updates"
    if repo is not None and repo.use_remote_url:
        return False, "Updates come from the remote repository it was installed from"
    return True, ""


def check(manual=False):
    """Start a check in the background (no-op while one is running)."""
    ok, why = can_self_update()
    if not ok:
        State.status = why
        return
    if not bpy.app.online_access:
        State.status = "Online access is off (Preferences > System > Network)"
        return
    if State.busy:
        return
    State.busy = True
    State.status = "Checking for updates…"
    State.last_check = time.time()
    threading.Thread(target=_run, args=(installed_version(), tuple(bpy.app.version)), daemon=True).start()


def _run(current, blender):
    try:
        url = INDEX_URL
        if url.startswith("http"):  # sidestep stale CDN copies
            url += ("&" if "?" in url else "?") + f"t={int(time.time() // 300)}"
        data = net.get_json(url)
        entry = next((e for e in data.get("data", []) if e.get("id") == PKG_ID), None)
        if entry is None:
            State.status = "No release found"
            return
        State.latest = entry["version"]
        if _key(entry["version"]) <= _key(current):
            State.status = f"Up to date ({current})"
            return
        if _key(entry.get("blender_version_min", "0")) > blender[:3]:
            State.status = f"{entry['version']} needs Blender {entry['blender_version_min']}"
            return
        url = urllib.parse.urljoin(INDEX_URL, entry["archive_url"])
        dest = os.path.join(tempfile.gettempdir(), "dataset_assets_update", f"{PKG_ID}-{entry['version']}.zip")
        if os.path.exists(dest):
            os.remove(dest)
        State.status = f"Downloading {entry['version']}…"
        net.download(url, dest)
        h = hashlib.sha256()
        with open(dest, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        want = entry.get("archive_hash", "")
        if (want and want != "sha256:" + h.hexdigest()) or \
                (entry.get("archive_size") and os.path.getsize(dest) != entry["archive_size"]):
            os.remove(dest)
            State.status = "Update download didn't match the release; skipped"
            return
        State.ready = (entry["version"], dest)
        State.status = f"Version {entry['version']} ready to install"
    except Exception as ex:  # offline, GitHub down, ...: try again next time
        State.status = f"Couldn't check for updates: {str(ex)[:120]}"
    finally:
        State.busy = False


def _safe_to_install():
    from . import fab, jobs, window
    return jobs.CURRENT is None and fab.State.current is None and not window.is_open()


def _install():
    version, path = State.ready
    State.ready = None
    try:  # the new version reads this once and tells the user
        with open(NOTE, "w", encoding="utf-8") as f:
            f.write(f"{installed_version()} {version}")
    except OSError:
        pass
    module, _ = _repo()
    wm = bpy.context.window_manager
    if not wm.windows:
        return
    win = wm.windows[0]
    print(f"dataset_assets: installing update {version}")
    try:
        with bpy.context.temp_override(window=win, screen=win.screen):
            # Replaces this add-on in place: Blender disables it, swaps the files and enables
            # the new version (which registers its own timers again).
            bpy.ops.extensions.package_install_files(
                filepath=path, repo=module, enable_on_install=True, overwrite=True)
    except Exception as ex:
        State.status = f"Update to {version} failed: {str(ex)[:120]}"
        print("dataset_assets:", State.status)
        return
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    State.installed = version
    print(f"dataset_assets: updated to {version}")


def tick():
    """Persistent timer: first check after startup, then every few hours; install when safe."""
    try:
        p = _prefs()
        auto = p is None or p.auto_update
        if auto and not State.busy and State.ready is None and \
                (State.last_check == 0.0 or time.time() - State.last_check > RECHECK):
            check()
        if State.ready is not None and auto and _safe_to_install():
            _install()
            return None  # the new version registers its own timer
    except Exception as ex:
        print("dataset_assets updater:", ex)
    return 30.0


class DSA_OT_check_update(bpy.types.Operator):
    bl_idname = "dataset_assets.check_update"
    bl_label = "Check for Updates"
    bl_description = "Look for a newer version on GitHub and install it"

    def execute(self, context):
        if State.ready is not None and _safe_to_install():
            _install()
            return {"FINISHED"}
        check(manual=True)
        if State.ready is None:
            bpy.app.timers.register(_finish_manual, first_interval=1.0)
        return {"FINISHED"}


def _finish_manual():
    if State.busy:
        return 1.0
    if State.ready is not None and _safe_to_install():
        _install()
    return None


def _announce():
    try:
        with open(NOTE, encoding="utf-8") as f:
            old, new = f.read().split()
        os.remove(NOTE)
    except (OSError, ValueError):
        return
    if new == installed_version():
        State.status = f"Updated from {old} to {new}"
        from . import jobs
        jobs.message(f"Dataset Assets updated to {new}")


def register():
    bpy.utils.register_class(DSA_OT_check_update)
    _announce()
    if not bpy.app.background:
        bpy.app.timers.register(tick, first_interval=FIRST_CHECK, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    if bpy.app.timers.is_registered(_finish_manual):
        bpy.app.timers.unregister(_finish_manual)
    bpy.utils.unregister_class(DSA_OT_check_update)
